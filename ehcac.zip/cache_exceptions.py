"""
Cache exceptions.
Location: src/app/exceptions/cache_exceptions.py

All exceptions raised by the Redis client and cache service layer.
Callers catch these to decide whether to fall back to the live path.
"""
from __future__ import annotations


class CacheError(Exception):
    """Base class for all cache-layer exceptions."""

    def __init__(self, msg: str, error_code: str) -> None:
        super().__init__(msg)
        self.msg = msg
        self.error_code = error_code


class CacheConnectionError(CacheError):
    """Redis is unreachable or the connection pool is exhausted."""


class CacheSerialiseError(CacheError):
    """dill could not serialise the tool objects."""


class CacheDeserialiseError(CacheError):
    """dill could not deserialise the stored blob (corrupt or version mismatch)."""


class CacheKeyError(CacheError):
    """The requested key does not exist in Redis."""
