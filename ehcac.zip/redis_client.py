"""
Redis client.
Location: src/app/core/redis_client.py

A thin async wrapper around redis-py that the CacheService depends on.

Design decisions
----------------
* decode_responses=False  — the cache stores raw dill bytes, not strings.
  If you already have a string-mode Redis client elsewhere, this is a
  second independent client for the cache only.
* Fail-open on every operation — a Redis error is logged and swallowed
  so the caller can fall back to the live path transparently.
* Health-check via ping() is called at startup; if it fails the client
  is set to None so every subsequent operation is a no-op.
* Single connection pool shared across all requests in the process.
"""
from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from ..exceptions.cache_exceptions import CacheConnectionError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

REDIS_DEFAULT_MAX_CONNECTIONS: int = 20
REDIS_DEFAULT_SOCKET_TIMEOUT: float = 1.0
REDIS_DEFAULT_SOCKET_CONNECT_TIMEOUT: float = 1.0


# ---------------------------------------------------------------------------
# Settings model — validated by Pydantic, read from app Settings
# ---------------------------------------------------------------------------

class RedisSettings(BaseModel):
    """
    Validated configuration for the Redis connection.

    Merge these fields into your application Settings class:

        class Settings(BaseSettings):
            redis_url: str = "redis://localhost:6379/0"
            redis_max_connections: int = 20
            redis_socket_timeout: float = 1.0
            redis_socket_connect_timeout: float = 1.0

    Environment variables (auto-mapped):
        REDIS_URL
        REDIS_MAX_CONNECTIONS
        REDIS_SOCKET_TIMEOUT
        REDIS_SOCKET_CONNECT_TIMEOUT
    """

    model_config = ConfigDict(extra="forbid")

    redis_url: str = Field(
        description="Redis connection URL (redis://, rediss://).",
        examples=["redis://localhost:6379/0", "rediss://:password@host:6380/0"],
    )
    redis_max_connections: int = Field(
        default=REDIS_DEFAULT_MAX_CONNECTIONS,
        ge=1,
        le=200,
        description="Maximum connections in the async pool.",
    )
    redis_socket_timeout: float = Field(
        default=REDIS_DEFAULT_SOCKET_TIMEOUT,
        gt=0,
        description="Seconds to wait for a command response.",
    )
    redis_socket_connect_timeout: float = Field(
        default=REDIS_DEFAULT_SOCKET_CONNECT_TIMEOUT,
        gt=0,
        description="Seconds to wait when opening a new connection.",
    )

    @field_validator("redis_url")
    @classmethod
    def url_must_not_be_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("redis_url must not be empty")
        return v


# ---------------------------------------------------------------------------
# RedisClient
# ---------------------------------------------------------------------------

class RedisClient:
    """
    Async Redis client wrapping redis-py.

    Lifecycle
    ---------
    Instantiate at lifespan startup, call connect(), store on app.state.
    Call disconnect() in the lifespan finally block.

    All get/set/delete operations are fail-open — they catch every Redis
    exception, log it at WARNING, and return a sentinel (None / False / 0).

    Usage
    -----
        # lifespan
        redis_client = RedisClient(settings=RedisSettings(redis_url="redis://..."))
        await redis_client.connect()
        app.state.redis_client = redis_client
        ...
        await redis_client.disconnect()

        # inside a service
        blob = await redis_client.get_bytes("my:key")
        await redis_client.set_bytes("my:key", blob, ttl_seconds=300)
    """

    def __init__(self, *, settings: RedisSettings) -> None:
        self._settings = settings
        self._client: Any = None  # redis.asyncio.Redis

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """
        Create the connection pool and verify connectivity with PING.
        Raises CacheConnectionError if Redis is unreachable at startup.
        """
        try:
            import redis.asyncio as aioredis  # noqa: PLC0415
        except ImportError as exc:
            raise CacheConnectionError(
                msg="redis[asyncio] is not installed. Run: pip install redis[asyncio]",
                error_code="AAPMDC_REDIS_NOT_INSTALLED",
            ) from exc

        try:
            self._client = aioredis.from_url(
                self._settings.redis_url,
                max_connections=self._settings.redis_max_connections,
                socket_timeout=self._settings.redis_socket_timeout,
                socket_connect_timeout=self._settings.redis_socket_connect_timeout,
                retry_on_timeout=True,
                decode_responses=False,  # bytes mode — required for dill blobs
            )
            await self._client.ping()
            logger.info("RedisClient connected: %s", self._settings.redis_url)
        except Exception as exc:  # pylint: disable=broad-except
            self._client = None
            raise CacheConnectionError(
                msg=f"Redis connection failed: {exc}",
                error_code="AAPMDC_REDIS_CONNECT_FAILED",
            ) from exc

    async def disconnect(self) -> None:
        """Close the connection pool gracefully."""
        if self._client is not None:
            try:
                await self._client.aclose()
                logger.info("RedisClient disconnected.")
            except Exception as exc:  # pylint: disable=broad-except
                logger.warning("RedisClient disconnect error: %s", exc)
            finally:
                self._client = None

    @property
    def is_connected(self) -> bool:
        return self._client is not None

    async def ping(self) -> bool:
        """Returns True if Redis responds. Used by health-check endpoints."""
        if not self.is_connected:
            return False
        try:
            return bool(await self._client.ping())
        except Exception:  # pylint: disable=broad-except
            return False

    # ------------------------------------------------------------------
    # Byte-level operations (used by CacheService for dill blobs)
    # ------------------------------------------------------------------

    async def get_bytes(self, key: str) -> bytes | None:
        """
        Return raw bytes for *key*, or None on miss / error.
        Never raises.
        """
        if not self.is_connected:
            return None
        try:
            return await self._client.get(key)
        except Exception as exc:  # pylint: disable=broad-except
            logger.warning("RedisClient GET %s failed: %s", key, exc)
            return None

    async def set_bytes(
        self,
        key: str,
        value: bytes,
        *,
        ttl_seconds: int,
    ) -> bool:
        """
        Store raw bytes under *key* with TTL.
        Returns True on success, False on error.
        Never raises.
        """
        if not self.is_connected:
            return False
        try:
            await self._client.set(key, value, ex=ttl_seconds)
            return True
        except Exception as exc:  # pylint: disable=broad-except
            logger.warning("RedisClient SET %s failed: %s", key, exc)
            return False

    async def delete(self, key: str) -> int:
        """
        Delete *key*. Returns number of keys deleted (0 or 1).
        Never raises.
        """
        if not self.is_connected:
            return 0
        try:
            return int(await self._client.delete(key))
        except Exception as exc:  # pylint: disable=broad-except
            logger.warning("RedisClient DEL %s failed: %s", key, exc)
            return 0

    async def scan_delete(self, pattern: str) -> int:
        """
        Delete all keys matching *pattern* using SCAN (non-blocking).
        Returns total number of keys deleted.
        Used by the cache invalidation admin endpoint.
        Never raises.
        """
        if not self.is_connected:
            return 0
        deleted = 0
        try:
            cursor = 0
            while True:
                cursor, keys = await self._client.scan(
                    cursor, match=pattern, count=100
                )
                if keys:
                    await self._client.delete(*keys)
                    deleted += len(keys)
                if cursor == 0:
                    break
        except Exception as exc:  # pylint: disable=broad-except
            logger.warning("RedisClient SCAN+DEL %s failed: %s", pattern, exc)
        return deleted
