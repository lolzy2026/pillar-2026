"""
Cache service.
Location: src/app/core/cache_service.py

Responsibilities
----------------
* Serialise / deserialise LangChain StructuredTool objects with dill.
* Strip auth token from tool closures before storing.
* Re-inject fresh auth token after retrieval.
* Read/write tool blobs keyed by role fingerprint.

Why dill works here
-------------------
MultiServerMCPClient.get_tools() uses session=None — the stateless path.
Each tool closure captures only plain data:
    connection: dict  (url, transport, headers)
    tool: mcp.types.Tool  (Pydantic model)
    session: None
    server_name: str
No asyncio streams or OS file descriptors are captured.

Auth token stripping / injection
---------------------------------
The connection dict inside each tool closure contains:
    headers: {"Authorization": "Bearer <jwt>", ...}

Before SET : auth headers stripped from a deep-copied tool list.
After GET  : current request's fresh JWT injected into every tool.
The stored blob never contains a credential.

Cache key
---------
    data_mcp:tools:{fingerprint}
    fingerprint = SHA-256[:16] of sorted(user_roles)

Users with identical roles share one cache entry.
Different namespaces / permissions get independent entries.
"""
from __future__ import annotations

import hashlib
import logging
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from ..exceptions.cache_exceptions import (
    CacheDeserialiseError,
    CacheSerialiseError,
)
from .redis_client import RedisClient

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

TOOL_CACHE_KEY_PREFIX: str = "data_mcp:tools:"
TOOL_CACHE_KEY_PATTERN: str = "data_mcp:tools:*"  # used for scan_delete
FINGERPRINT_LENGTH: int = 16
BEARER_PREFIX: str = "Bearer "

# Auth header keys to strip (checked case-insensitively)
_AUTH_HEADER_KEYS: frozenset[str] = frozenset(
    {"authorization", "x-auth-token", "x-api-key"}
)

# Closure free-variable name that holds the connection dict
_CONNECTION_FREE_VAR: str = "connection"

# Default TTL — must be <= JWT expiry; override via CacheSettings
DEFAULT_TOOL_CACHE_TTL_SECONDS: int = 300


# ---------------------------------------------------------------------------
# Settings model
# ---------------------------------------------------------------------------

class CacheSettings(BaseModel):
    """
    Validated configuration for the CacheService.

    Merge these fields into your application Settings class and pass
    a populated instance to CacheService().

        class Settings(BaseSettings):
            tool_cache_ttl_seconds: int = 300

    Environment variable:
        TOOL_CACHE_TTL_SECONDS
    """

    model_config = ConfigDict(extra="forbid")

    tool_cache_ttl_seconds: int = Field(
        default=DEFAULT_TOOL_CACHE_TTL_SECONDS,
        ge=30,
        le=86400,
        description=(
            "TTL for cached tool blobs in Redis. "
            "Must be <= your JWT token expiry. "
            "Default 300 s (5 min)."
        ),
    )

    @field_validator("tool_cache_ttl_seconds")
    @classmethod
    def ttl_must_be_positive(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("tool_cache_ttl_seconds must be > 0")
        return v


# ---------------------------------------------------------------------------
# CacheService
# ---------------------------------------------------------------------------

class CacheService:
    """
    Tool cache service backed by Redis.

    One instance lives on app.state, shared across all requests.

    Public interface
    ----------------
    get_tools(roles, auth_token)   → list[StructuredTool] | None
    set_tools(roles, tools, auth_token)
    invalidate(roles)
    invalidate_all()

    All methods are fail-open — any exception is caught and logged so
    the caller can fall back to the live list_tools() path.
    """

    def __init__(
        self,
        redis_client: RedisClient,
        settings: CacheSettings,
    ) -> None:
        self._redis = redis_client
        self._settings = settings

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def get_tools(
        self,
        roles: list[str] | set[str],
        auth_token: str,
    ) -> list[Any] | None:
        """
        Try to load tools from Redis for *roles*.

        Returns a list of ready-to-use StructuredTool objects with the
        current *auth_token* injected, or None on miss / error.

        Parameters
        ----------
        roles :
            The user's namespace/role list from the JWT.
        auth_token :
            Current request JWT — injected into every retrieved tool.
        """
        key = self._make_key(roles)

        try:
            blob = await self._redis.get_bytes(key)
        except Exception as exc:  # pylint: disable=broad-except
            logger.warning("CacheService GET redis error key=%s: %s", key, exc)
            return None

        if blob is None:
            logger.debug("CacheService GET MISS key=%s", key)
            return None

        try:
            tools = self._deserialise(blob)
        except CacheDeserialiseError as exc:
            logger.warning(
                "CacheService corrupt blob key=%s — evicting. %s",
                key, exc.msg,
            )
            await self._redis.delete(key)
            return None

        tools = self._inject_auth(tools, auth_token=auth_token)
        logger.debug("CacheService GET HIT  key=%s tools=%d", key, len(tools))
        return tools

    async def set_tools(
        self,
        roles: list[str] | set[str],
        tools: list[Any],
        auth_token: str,
    ) -> None:
        """
        Strip auth and store *tools* in Redis.

        Parameters
        ----------
        roles :
            User's namespace/role list — derives the cache key.
        tools :
            configurable["available_tools"] from ToolsLoaderService.
        auth_token :
            Current JWT — stripped before storing.
        """
        if not tools:
            logger.debug("CacheService SET skipped — empty tools list")
            return

        key = self._make_key(roles)

        try:
            stripped = self._strip_auth(tools, auth_token=auth_token)
            blob = self._serialise(stripped)
        except (CacheSerialiseError, CacheDeserialiseError) as exc:
            logger.warning("CacheService SET serialise failed key=%s: %s", key, exc.msg)
            return

        try:
            ok = await self._redis.set_bytes(
                key,
                blob,
                ttl_seconds=self._settings.tool_cache_ttl_seconds,
            )
        except Exception as exc:  # pylint: disable=broad-except
            logger.warning("CacheService SET redis error key=%s: %s", key, exc)
            return

        if ok:
            logger.debug(
                "CacheService SET key=%s tools=%d ttl=%ds bytes=%d",
                key, len(tools), self._settings.tool_cache_ttl_seconds, len(blob),
            )
        else:
            logger.warning("CacheService SET failed key=%s", key)

    async def invalidate(self, roles: list[str] | set[str]) -> None:
        """Evict the cache entry for *roles* (e.g. after a role change)."""
        key = self._make_key(roles)
        deleted = await self._redis.delete(key)
        logger.info("CacheService INVALIDATE key=%s deleted=%d", key, deleted)

    async def invalidate_all(self) -> None:
        """
        Evict ALL tool cache entries using SCAN.
        Call after a tool deployment to force all workers to re-fetch.
        """
        deleted = await self._redis.scan_delete(TOOL_CACHE_KEY_PATTERN)
        logger.info("CacheService INVALIDATE_ALL deleted=%d keys", deleted)

    # ------------------------------------------------------------------
    # Key helpers
    # ------------------------------------------------------------------

    @staticmethod
    def make_fingerprint(roles: list[str] | set[str]) -> str:
        """
        Return the role-set fingerprint used as the cache key suffix.
        Order-independent, deterministic.
        """
        sorted_roles = "|".join(sorted(str(r) for r in roles))
        return hashlib.sha256(sorted_roles.encode()).hexdigest()[:FINGERPRINT_LENGTH]

    @staticmethod
    def _make_key(roles: list[str] | set[str]) -> str:
        return TOOL_CACHE_KEY_PREFIX + CacheService.make_fingerprint(roles)

    # ------------------------------------------------------------------
    # Serialise / deserialise
    # ------------------------------------------------------------------

    @staticmethod
    def _serialise(tools: list[Any]) -> bytes:
        """
        Serialise *tools* to bytes using dill.

        Raises CacheSerialiseError on failure.
        """
        try:
            import dill  # noqa: PLC0415
        except ImportError as exc:
            raise CacheSerialiseError(
                msg="dill is not installed. Run: pip install dill",
                error_code="AAPMDC_CACHE_DILL_MISSING",
            ) from exc

        try:
            return dill.dumps(tools, recurse=True)
        except Exception as exc:  # pylint: disable=broad-except
            raise CacheSerialiseError(
                msg=f"dill serialisation failed: {exc}",
                error_code="AAPMDC_CACHE_SERIALISE_FAILED",
            ) from exc

    @staticmethod
    def _deserialise(blob: bytes) -> list[Any]:
        """
        Deserialise bytes back to a list of tool objects.

        Raises CacheDeserialiseError on failure.
        """
        try:
            import dill  # noqa: PLC0415
        except ImportError as exc:
            raise CacheDeserialiseError(
                msg="dill is not installed. Run: pip install dill",
                error_code="AAPMDC_CACHE_DILL_MISSING",
            ) from exc

        try:
            return dill.loads(blob)  # noqa: S301
        except Exception as exc:  # pylint: disable=broad-except
            raise CacheDeserialiseError(
                msg=f"dill deserialisation failed: {exc}",
                error_code="AAPMDC_CACHE_DESERIALISE_FAILED",
            ) from exc

    # ------------------------------------------------------------------
    # Auth strip / inject
    # ------------------------------------------------------------------

    @staticmethod
    def _strip_auth(tools: list[Any], *, auth_token: str) -> list[Any]:  # noqa: ARG004
        """
        Return a deep-copied list of tools with auth headers removed.
        Does NOT mutate the originals.
        auth_token param kept for API symmetry; not used in logic.
        """
        import dill  # noqa: PLC0415

        result: list[Any] = []
        for tool in tools:
            try:
                # Deep-copy via dill round-trip — fully independent object
                tool_copy = dill.loads(dill.dumps(tool, recurse=True))  # noqa: S301
                conn = CacheService._get_connection(tool_copy)
                if conn is not None:
                    headers: dict = conn.get("headers") or {}
                    conn["headers"] = {
                        k: v
                        for k, v in headers.items()
                        if k.lower() not in _AUTH_HEADER_KEYS
                    }
                result.append(tool_copy)
            except Exception as exc:  # pylint: disable=broad-except
                logger.debug(
                    "CacheService strip_auth skipped tool %s: %s",
                    getattr(tool, "name", "?"), exc,
                )
                result.append(tool)
        return result

    @staticmethod
    def _inject_auth(tools: list[Any], *, auth_token: str) -> list[Any]:
        """
        Inject the current JWT into every tool's connection dict in-place.
        Modifies the already-deserialised copies — safe to mutate.
        """
        for tool in tools:
            try:
                conn = CacheService._get_connection(tool)
                if conn is not None:
                    headers: dict = conn.get("headers") or {}
                    headers["Authorization"] = f"{BEARER_PREFIX}{auth_token}"
                    conn["headers"] = headers
            except Exception as exc:  # pylint: disable=broad-except
                logger.debug(
                    "CacheService inject_auth skipped tool %s: %s",
                    getattr(tool, "name", "?"), exc,
                )
        return tools

    # ------------------------------------------------------------------
    # Closure introspection
    # ------------------------------------------------------------------

    @staticmethod
    def _get_connection(tool: Any) -> dict | None:
        """
        Locate the `connection` dict inside a tool's coroutine closure.

        The closure of convert_mcp_tool_to_langchain_tool()'s inner
        `call_tool` coroutine contains:
            ('callbacks', 'connection', 'server_name', 'session',
             'tool', 'tool_interceptors')

        Returns the mutable dict reference, or None if not found.
        """
        coroutine = getattr(tool, "coroutine", None)
        if coroutine is None:
            return None

        code = getattr(coroutine, "__code__", None)
        if code is None:
            return None

        free_vars: tuple[str, ...] = code.co_freevars
        closure = getattr(coroutine, "__closure__", None)

        if not closure or _CONNECTION_FREE_VAR not in free_vars:
            return None

        idx = free_vars.index(_CONNECTION_FREE_VAR)
        try:
            value = closure[idx].cell_contents
            if isinstance(value, dict):
                return value
        except ValueError:
            pass

        return None
