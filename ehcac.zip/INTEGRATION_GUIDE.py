"""
Integration Guide — Tool Caching
=================================
Location: INTEGRATION_GUIDE.md  (rename this file)

NEW FILES  (drop in as-is, no edits required)
----------------------------------------------
  src/app/exceptions/cache_exceptions.py
  src/app/core/redis_client.py
  src/app/core/cache_service.py
  src/app/services/data_mcp_client_service.py   ← replaces existing

EXISTING FILES THAT NEED CHANGES
---------------------------------
  requirements.txt / pyproject.toml     Step 1
  src/app/core/settings.py              Step 2
  src/app/main.py                       Step 3
  src/app/factory/factory.py            Step 4
  src/app/api/data_mcp_client.py        Step 5  (optional admin endpoint)

NO CHANGES to:
  session_manager.py, session_models.py, elicitation_handler.py,
  data_mcp_client_api.py, langchain_mcp_client.py, tools_service.py,
  loaders.py, data_mcp_client_request_updated.py

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 1  requirements.txt / pyproject.toml
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    dill>=0.3.8
    redis[asyncio]>=5.0.0

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 2  src/app/core/settings.py  (add to your existing Settings class)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    from pydantic import Field
    from pydantic_settings import BaseSettings

    class Settings(BaseSettings):
        # ... your existing fields ...

        # ── Cache ────────────────────────────────────────────────────
        redis_url: str = Field(
            default="",
            description=(
                "Redis connection URL. Leave empty to disable tool caching. "
                "Example: redis://localhost:6379/0"
            ),
        )
        redis_max_connections: int = Field(default=20, ge=1, le=200)
        redis_socket_timeout: float = Field(default=1.0, gt=0)
        redis_socket_connect_timeout: float = Field(default=1.0, gt=0)

        tool_cache_ttl_seconds: int = Field(
            default=300,
            ge=30,
            le=86400,
            description=(
                "TTL for cached tool blobs. Must be <= your JWT expiry. "
                "Default 300 s (5 min)."
            ),
        )

Environment variables (auto-mapped by Pydantic):
    REDIS_URL=redis://your-redis-host:6379/0
    TOOL_CACHE_TTL_SECONDS=300

To DISABLE caching: set REDIS_URL="" (empty string, the default).
The service falls back to the original get_tools() path transparently.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 3  src/app/main.py  (lifespan function)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Add the marked blocks inside your existing lifespan().
Everything outside the marked blocks is UNCHANGED.

    from ..core.redis_client import RedisClient, RedisSettings
    from ..core.cache_service import CacheService, CacheSettings
    from ..exceptions.cache_exceptions import CacheConnectionError

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        threads: list[Thread] = []
        stop_event = Event()

        # ── NEW: Redis + CacheService ─────────────────────────────────
        cache_service: CacheService | None = None
        redis_client: RedisClient | None = None

        if settings.redis_url:
            redis_settings = RedisSettings(
                redis_url=settings.redis_url,
                redis_max_connections=settings.redis_max_connections,
                redis_socket_timeout=settings.redis_socket_timeout,
                redis_socket_connect_timeout=settings.redis_socket_connect_timeout,
            )
            redis_client = RedisClient(settings=redis_settings)
            try:
                await redis_client.connect()
                cache_service = CacheService(
                    redis_client=redis_client,
                    settings=CacheSettings(
                        tool_cache_ttl_seconds=settings.tool_cache_ttl_seconds,
                    ),
                )
                logger.info("Tool cache enabled (TTL=%ds)", settings.tool_cache_ttl_seconds)
            except CacheConnectionError as exc:
                logger.warning(
                    "Tool cache DISABLED — Redis unavailable: %s", exc.msg
                )
                redis_client = None
                cache_service = None
        else:
            logger.info("Tool cache DISABLED — REDIS_URL not set")

        _.state.redis_client = redis_client    # None if cache disabled
        _.state.cache_service = cache_service  # None if cache disabled
        # ─────────────────────────────────────────────────────────────

        # ── EXISTING: SessionManager ──────────────────────────────────
        session_manager = SessionManager(default_ttl_seconds=300)
        session_manager.start()
        _.state.session_manager = session_manager
        # ─────────────────────────────────────────────────────────────

        try:
            ServerUtils.register_and_send_heartbeat(...)
            ...
            async for data_mcp_client_agent in setup_data_mcp_client_agent(...):
                yield {"data_mcp_client_agent": data_mcp_client_agent}

        except Exception as e:
            logger.error("Lifespan error: %s", e, exc_info=True)

        finally:
            # Shutdown order: SessionManager first, then Redis
            await session_manager.stop()

            # ── NEW: Redis shutdown ───────────────────────────────────
            if redis_client is not None:
                await redis_client.disconnect()
            # ─────────────────────────────────────────────────────────

            stop_event.set()
            for thread in threads:
                thread.join()

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 4  src/app/factory/factory.py  (add to existing Factory class)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Add the two methods below to your Factory class alongside the existing
get_session_manager() and get_data_mcp_client_service() methods.

    from fastapi import Request
    from ..core.redis_client import RedisClient
    from ..core.cache_service import CacheService

    class Factory:
        # ... existing methods ...

        @staticmethod
        def get_redis_client(request: Request) -> RedisClient | None:
            \"\"\"FastAPI dependency — returns the singleton RedisClient or None.\"\"\"
            return request.app.state.redis_client

        @staticmethod
        def get_cache_service(request: Request) -> CacheService | None:
            \"\"\"FastAPI dependency — returns the singleton CacheService or None.\"\"\"
            return request.app.state.cache_service

Note: data_mcp_client_service.py reads cache_service directly from
app.state (same pattern as request.state.data_mcp_client_agent).
You do not need to inject it via factory for normal request handling —
only for the optional admin endpoint below.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 5  Cache invalidation endpoint  (optional — add to admin router)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Add to your internal/admin router.  Call after deploying new MCP tools
to force all workers to re-fetch without restarting the service.

    from typing import Annotated
    from fastapi import APIRouter, Depends, Request
    from bmc_ami_ai_shared.entities import BaseResponse
    from ..core.cache_service import CacheService
    from ..factory import factory

    CacheServiceDep = Annotated[
        CacheService | None,
        Depends(factory.get_cache_service),
    ]

    admin_router = APIRouter(prefix="/admin/cache")

    @admin_router.post("/tools/invalidate", response_model=BaseResponse)
    async def invalidate_tool_cache(
        cache_service: CacheServiceDep,
    ) -> BaseResponse:
        \"\"\"
        Evict all tool cache entries.
        Call after deploying new MCP tool definitions.
        \"\"\"
        if cache_service is None:
            return BaseResponse(data={"status": "cache_disabled"})

        await cache_service.invalidate_all()
        return BaseResponse(data={"status": "ok"})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TTL GUIDE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    JWT expiry    Recommended TOOL_CACHE_TTL_SECONDS
    ────────────────────────────────────────────────
    15 min        600   (must stay < JWT expiry)
    60 min        300   (default — safe for most cases)
    24 hr         3600  (for stable, infrequently-changed tools)

Rule: TTL must always be <= JWT expiry.
Token refresh is handled transparently — on each GET the current
request's fresh token is injected regardless of when the blob was written.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PER-MESSAGE FLOW  (after integration)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cold cache (first message from a role set):
    load_mcp_client()                    ~150ms  always
    cache_service.get_tools() → MISS     ~1ms
    load_mcp_tools_to_configurable()     ~60ms   list_tools() network call
    cache_service.set_tools()            ~2ms    write blob to Redis
    graph + LLM                          ~1000ms+

Warm cache (all subsequent messages):
    load_mcp_client()                    ~150ms  always
    cache_service.get_tools() → HIT      ~2ms    read + token inject
    (list_tools skipped)
    graph + LLM                          ~1000ms+

    Saving: ~58ms per message after the first.
"""
