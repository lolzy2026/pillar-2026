"""
Updated DataMCPClientService with tool caching.
Location: src/app/services/data_mcp_client_service.py

Changes vs session-management version
--------------------------------------
Only step 3b (tool loading) is changed.  Everything else is identical.

Before:
    configurable = await ToolsLoaderService.load_mcp_tools_to_configurable(...)

After (new-session path only):
    1. cache_service.get_tools(roles, token) → hit: skip list_tools()
    2. miss: load_mcp_tools_to_configurable() → cache_service.set_tools(...)

The cache_service is optional (may be None if Redis is unavailable).
If None, behaviour is identical to the original.

Imports added:
    from ..core.cache_service import CacheService  (new)
    datetime and asyncio imported properly (removes __import__ hack)
"""
from __future__ import annotations

import asyncio
import datetime
import json
from typing import Any, AsyncGenerator
from uuid import UUID

from fastapi import Request
from langchain_core.messages import HumanMessage

from ..core.cache_service import CacheService
from ..core.elicitation_handler import build_elicitation_callback
from ..core.logger import logger
from ..core.session_manager import SessionManager
from ..entities.data_mcp_client_agent_context import DataMCPClientAgentContext
from ..entities.expert_request_processing import ExpertRequestProcessing
from ..entities.request.data_mcp_client_request import DataaMCPClientRequest
from ..entities.response.data_mcp_client_response import DataMCPClientResponse
from ..entities.session_models import QueueEventType
from ..factory import LLMFactory
from ..services.mcp_adapter_service import MCPClientAdapterService
from ..services.tools_service import ToolsLoaderService
from ..core import jwt_utils
from ..entities.enums import ServiceType, MessageMode


class DataMCPClientService:
    """Service layer for Data MCP Client conversation."""

    def __init__(self, session_manager: SessionManager) -> None:
        self._session_manager = session_manager

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    @staticmethod
    async def generate_response(
        data_mcp_client_request: DataaMCPClientRequest,
        auth_token: str,
        original_auth_token: str,
        request: Request,
        session_manager: SessionManager,
    ) -> DataMCPClientResponse | AsyncGenerator[str, Any]:
        """
        Perform Data MCP Client service tasks.

        Resume path (session_id provided): UNCHANGED.
        New session path: tool loading wrapped with cache read/write.
        """
        # ----------------------------------------------------------------
        # 1. Auth + processing details  (UNCHANGED)
        # ----------------------------------------------------------------
        token_data = jwt_utils.get_claims_from_token(auth_token, ServiceType.EXPERT)
        is_external = token_data.get("external", False)

        processing_details = ExpertRequestProcessing(
            user_details=jwt_utils.get_user_from_jwt(auth_token, ServiceType.EXPERT),
            expert_id=data_mcp_client_request.expert_id,
            conversation_id=data_mcp_client_request.conversation_id,
            message_id=data_mcp_client_request.message.message_id,
        )

        user_id = processing_details.user_details.user_id
        user_persona = processing_details.user_details.persona
        start_timestamp = int(
            datetime.datetime.now(datetime.timezone.utc).timestamp()
        )

        metadata_dict = {
            "request_source": data_mcp_client_request.source,
            "request_type": data_mcp_client_request.request_type,
            "max_tokens": data_mcp_client_request.llm_info.max_tokens,
            "user_id": user_id,
            "message_id": str(data_mcp_client_request.message.message_id),
            "start_timestamp": start_timestamp,
            "confidence": 0.8,
            "references": "reference list",
            "attachments": "attachment list",
            "mode": MessageMode.ASSIST.value,
        }

        # ----------------------------------------------------------------
        # 2. RESUME path  (UNCHANGED)
        # ----------------------------------------------------------------
        if data_mcp_client_request.session_id:
            session_id = UUID(str(data_mcp_client_request.session_id))
            session = session_manager.get_session(session_id)
            logger.debug("Resuming session %s", session_id)

            if data_mcp_client_request.is_stream:
                return DataMCPClientService._stream_from_session(
                    session=session,
                    session_manager=session_manager,
                    processing_details=processing_details,
                )
            return await DataMCPClientService._collect_non_stream(
                session=session,
                session_manager=session_manager,
                processing_details=processing_details,
            )

        # ----------------------------------------------------------------
        # 3. NEW session path
        # ----------------------------------------------------------------
        llm = LLMFactory.create(data_mcp_client_request.llm_info)

        configurable = {
            "thread_id": str(processing_details.conversation_id),
            "llm_info": data_mcp_client_request.llm_info.model_dump(),
            "autocomplete": data_mcp_client_request.autocomplete,
            "original_auth_token": original_auth_token,
            "user_roles": processing_details.mcp_gw,
            "enable_parallel_tool_execution": False,
        }

        # -- 3a. Load MCP client (always required) -----------------------
        mcp_client = await MCPClientAdapterService.load_mcp_client(
            configurable=configurable,
        )

        # -- 3b. Tool loading with cache ---------------------------------
        cache_service: CacheService | None = getattr(
            request.app.state, "cache_service", None
        )
        user_roles = _extract_roles(processing_details)

        cached_tools = None
        if cache_service is not None:
            cached_tools = await cache_service.get_tools(
                roles=user_roles,
                auth_token=original_auth_token,
            )

        if cached_tools is not None:
            logger.debug(
                "Tool cache HIT user=%s tools=%d", user_id, len(cached_tools)
            )
            configurable["available_tools"] = cached_tools
            configurable["available_tools_name_map"] = (
                await ToolsLoaderService.build_tool_name_map(cached_tools)
            )
        else:
            logger.debug("Tool cache MISS user=%s — fetching from MCP", user_id)
            configurable = await ToolsLoaderService.load_mcp_tools_to_configurable(
                configurable=configurable,
                mcp_client=mcp_client,
            )
            if cache_service is not None:
                available_tools = configurable.get("available_tools", [])
                await cache_service.set_tools(
                    roles=user_roles,
                    tools=available_tools,
                    auth_token=original_auth_token,
                )

        # -- 3c. Build graph input  (UNCHANGED) --------------------------
        graph_input = {
            "messages": [
                HumanMessage(content=data_mcp_client_request.message.content)
            ],
            "user_persona": user_persona,
            "is_stream": data_mcp_client_request.is_stream,
            "is_external": is_external,
            "source_product": data_mcp_client_request.source,
        }

        # -- 3d. Build graph context  (UNCHANGED) ------------------------
        graph_context = DataMCPClientAgentContext(
            llm=llm,
            cancel_event=asyncio.Event(),
            mcp_client=mcp_client,
        )

        # -- 3e. Update LLM metadata  (UNCHANGED) ------------------------
        llm_type = data_mcp_client_request.llm_info.llm_type.value
        llm_metadata = data_mcp_client_request.llm_info.model_dump()
        llm_metadata["url"] = str(llm_metadata["url"])
        llm_metadata["llm_type"] = llm_type
        llm_metadata["is_stream"] = data_mcp_client_request.is_stream
        metadata_dict["url"] = llm_metadata["url"]
        metadata_dict.update(llm_metadata)

        # -- 3f. Create session + elicitation callback  (UNCHANGED) ------
        agent = request.state.data_mcp_client_agent

        session = await session_manager.create_session(
            mcp_client=mcp_client,
            agent=agent,
            graph_input=graph_input,
            graph_context=graph_context,
            configurable=configurable,
            metadata_dict=metadata_dict,
        )

        elicitation_callback = build_elicitation_callback(session)
        mcp_client.set_elicitation_handler(elicitation_callback)

        logger.debug("Created new session %s", session.session_id)

        # ----------------------------------------------------------------
        # 4. Stream or non-stream  (UNCHANGED)
        # ----------------------------------------------------------------
        if data_mcp_client_request.is_stream:
            return DataMCPClientService._stream_from_session(
                session=session,
                session_manager=session_manager,
                processing_details=processing_details,
            )

        return await DataMCPClientService._collect_non_stream(
            session=session,
            session_manager=session_manager,
            processing_details=processing_details,
        )

    # ------------------------------------------------------------------
    # Internal helpers  (UNCHANGED)
    # ------------------------------------------------------------------

    @staticmethod
    async def _stream_from_session(
        *,
        session: Any,
        session_manager: SessionManager,
        processing_details: ExpertRequestProcessing,
    ) -> AsyncGenerator[str, Any]:
        async for event in session_manager.consume_stream(session):
            if event.type == QueueEventType.TOKEN:
                payload = event.data or {}
                response = DataMCPClientResponse(
                    conversation_id=processing_details.conversation_id,
                    message={
                        "message_id": str(processing_details.message_id),
                        "content": payload.get("content", ""),
                        "confidence": 0.8,
                        "references": [],
                        "is_terminated": payload.get("is_terminated", False),
                        "is_finished": payload.get("is_finished", False),
                        "streaming_steps": payload.get("streaming_steps"),
                        "current_step": payload.get("current_step"),
                        "streaming_tag": payload.get("streaming_tag"),
                    },
                    session_id=str(session.session_id),
                )
                yield response.model_dump_json() + "\n"

            elif event.type == QueueEventType.ELICITATION:
                elicitation_data = event.data or {}
                elicitation_data["session_id"] = str(session.session_id)
                yield json.dumps({
                    "type": "elicitation",
                    "data": elicitation_data,
                    "session_id": str(session.session_id),
                }) + "\n"
                break

            elif event.type == QueueEventType.ERROR:
                yield json.dumps({
                    "type": "error",
                    "detail": (event.data or {}).get("detail", "Unknown error"),
                    "session_id": str(session.session_id),
                }) + "\n"
                break

            elif event.type == QueueEventType.DONE:
                break

    @staticmethod
    async def _collect_non_stream(
        *,
        session: Any,
        session_manager: SessionManager,
        processing_details: ExpertRequestProcessing,
    ) -> DataMCPClientResponse:
        collected_content = ""
        elicitation_payload = None
        is_terminated = False

        async for event in session_manager.consume_stream(session):
            if event.type == QueueEventType.TOKEN:
                payload = event.data or {}
                collected_content += payload.get("content", "")
                is_terminated = payload.get("is_terminated", False)
            elif event.type == QueueEventType.ELICITATION:
                elicitation_payload = event.data
                break
            elif event.type in (QueueEventType.DONE, QueueEventType.ERROR):
                break

        return DataMCPClientResponse(
            conversation_id=processing_details.conversation_id,
            message={
                "message_id": str(processing_details.message_id),
                "content": collected_content,
                "confidence": 0.8,
                "references": [],
                "is_terminated": is_terminated,
                "is_finished": elicitation_payload is None,
            },
            session_id=str(session.session_id),
            elicitation=elicitation_payload,
        )


# ---------------------------------------------------------------------------
# Private helper
# ---------------------------------------------------------------------------

def _extract_roles(processing_details: Any) -> list[str]:
    """
    Normalise processing_details.mcp_gw to a sorted list of strings.
    mcp_gw is the namespace/role set from the JWT, used as the cache key.
    """
    raw = getattr(processing_details, "mcp_gw", None) or []
    if isinstance(raw, str):
        roles = [r.strip() for r in raw.split(",") if r.strip()]
    elif isinstance(raw, (list, set, tuple)):
        roles = [str(r) for r in raw]
    else:
        roles = []
    return sorted(roles)
