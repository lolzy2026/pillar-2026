"""
Tests for RedisClient and CacheService.
Location: tests/core/test_cache.py

All tests use real LangChain tools built via convert_mcp_tool_to_langchain_tool
with session=None — the production code path.
Redis is mocked via AsyncMock.
"""
from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from langchain_mcp_adapters.tools import convert_mcp_tool_to_langchain_tool
from mcp.types import Tool as MCPTool

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_tool(
    name: str = "query_data",
    headers: dict | None = None,
) -> Any:
    """
    Build a real StructuredTool using the adapter's stateless path.
    Closure structure matches production exactly.
    """
    conn = {
        "transport": "sse",
        "url": "http://mcp-gateway/mcp",
        "headers": headers if headers is not None else {
            "Authorization": "Bearer old-token",
            "X-Tenant": "tenant-abc",
        },
    }
    mcp_tool = MCPTool(
        name=name,
        description=f"Tool {name}",
        inputSchema={
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    )
    return convert_mcp_tool_to_langchain_tool(
        session=None,
        tool=mcp_tool,
        connection=conn,
        server_name="test_server",
    )


def _get_headers(tool: Any) -> dict:
    """Read headers from a tool's closure connection dict."""
    from src.app.core.cache_service import CacheService
    conn = CacheService._get_connection(tool)
    assert conn is not None, "connection not found in closure"
    return conn.get("headers") or {}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_redis():
    r = AsyncMock()
    r.get = AsyncMock(return_value=None)
    r.set = AsyncMock(return_value=True)
    r.delete = AsyncMock(return_value=1)
    r.scan_delete = AsyncMock(return_value=0)
    r.is_connected = True
    return r


@pytest.fixture
def cache_service(mock_redis):
    from src.app.core.cache_service import CacheService, CacheSettings
    return CacheService(
        redis_client=mock_redis,
        settings=CacheSettings(tool_cache_ttl_seconds=300),
    )


@pytest.fixture
def in_memory_redis():
    """Real in-memory Redis substitute for lifecycle integration tests."""
    store: dict[str, bytes] = {}

    class InMemory:
        is_connected = True
        async def get_bytes(self, key): return store.get(key)
        async def set_bytes(self, key, value, *, ttl_seconds): store[key] = value; return True
        async def delete(self, key): return 1 if store.pop(key, None) is not None else 0
        async def scan_delete(self, pattern):
            keys = [k for k in list(store) if k.startswith(pattern.rstrip("*"))]
            for k in keys: store.pop(k, None)
            return len(keys)

    return InMemory()


# ═══════════════════════════════════════════════════════════════════
# RedisClient tests
# ═══════════════════════════════════════════════════════════════════

class TestRedisClientSettings:
    def test_valid_settings(self):
        from src.app.core.redis_client import RedisSettings
        s = RedisSettings(redis_url="redis://localhost:6379/0")
        assert s.redis_url == "redis://localhost:6379/0"
        assert s.redis_max_connections == 20

    def test_empty_url_raises(self):
        from src.app.core.redis_client import RedisSettings
        with pytest.raises(Exception):
            RedisSettings(redis_url="   ")

    def test_extra_fields_forbidden(self):
        from src.app.core.redis_client import RedisSettings
        with pytest.raises(Exception):
            RedisSettings(redis_url="redis://localhost", unknown_field="x")


class TestRedisClientConnect:
    @pytest.mark.asyncio
    async def test_connect_raises_cache_connection_error_when_redis_unreachable(self):
        from src.app.core.redis_client import RedisClient, RedisSettings
        from src.app.exceptions.cache_exceptions import CacheConnectionError

        settings = RedisSettings(redis_url="redis://nonexistent:6379/0")
        client = RedisClient(settings=settings)

        with patch("redis.asyncio.from_url") as mock_from_url:
            mock_redis = AsyncMock()
            mock_redis.ping = AsyncMock(side_effect=ConnectionRefusedError("refused"))
            mock_from_url.return_value = mock_redis

            with pytest.raises(CacheConnectionError) as exc_info:
                await client.connect()
            assert exc_info.value.error_code == "AAPMDC_REDIS_CONNECT_FAILED"
            assert not client.is_connected

    @pytest.mark.asyncio
    async def test_connect_sets_is_connected(self):
        from src.app.core.redis_client import RedisClient, RedisSettings

        settings = RedisSettings(redis_url="redis://localhost:6379/0")
        client = RedisClient(settings=settings)

        with patch("redis.asyncio.from_url") as mock_from_url:
            mock_redis = AsyncMock()
            mock_redis.ping = AsyncMock(return_value=True)
            mock_from_url.return_value = mock_redis
            await client.connect()

        assert client.is_connected

    @pytest.mark.asyncio
    async def test_disconnect_sets_not_connected(self):
        from src.app.core.redis_client import RedisClient, RedisSettings

        settings = RedisSettings(redis_url="redis://localhost:6379/0")
        client = RedisClient(settings=settings)

        with patch("redis.asyncio.from_url") as mock_from_url:
            mock_redis = AsyncMock()
            mock_redis.ping = AsyncMock(return_value=True)
            mock_redis.aclose = AsyncMock()
            mock_from_url.return_value = mock_redis
            await client.connect()
            await client.disconnect()

        assert not client.is_connected

    @pytest.mark.asyncio
    async def test_get_bytes_returns_none_when_not_connected(self):
        from src.app.core.redis_client import RedisClient, RedisSettings
        client = RedisClient(settings=RedisSettings(redis_url="redis://x:6379"))
        result = await client.get_bytes("any:key")
        assert result is None

    @pytest.mark.asyncio
    async def test_set_bytes_returns_false_when_not_connected(self):
        from src.app.core.redis_client import RedisClient, RedisSettings
        client = RedisClient(settings=RedisSettings(redis_url="redis://x:6379"))
        result = await client.set_bytes("any:key", b"data", ttl_seconds=60)
        assert result is False

    @pytest.mark.asyncio
    async def test_ping_returns_false_when_not_connected(self):
        from src.app.core.redis_client import RedisClient, RedisSettings
        client = RedisClient(settings=RedisSettings(redis_url="redis://x:6379"))
        assert await client.ping() is False


# ═══════════════════════════════════════════════════════════════════
# CacheSettings tests
# ═══════════════════════════════════════════════════════════════════

class TestCacheSettings:
    def test_default_ttl(self):
        from src.app.core.cache_service import CacheSettings
        s = CacheSettings()
        assert s.tool_cache_ttl_seconds == 300

    def test_custom_ttl(self):
        from src.app.core.cache_service import CacheSettings
        s = CacheSettings(tool_cache_ttl_seconds=600)
        assert s.tool_cache_ttl_seconds == 600

    def test_ttl_below_minimum_raises(self):
        from src.app.core.cache_service import CacheSettings
        with pytest.raises(Exception):
            CacheSettings(tool_cache_ttl_seconds=10)

    def test_extra_fields_forbidden(self):
        from src.app.core.cache_service import CacheSettings
        with pytest.raises(Exception):
            CacheSettings(unknown="x")


# ═══════════════════════════════════════════════════════════════════
# make_fingerprint tests
# ═══════════════════════════════════════════════════════════════════

class TestMakeFingerprint:
    def test_deterministic(self):
        from src.app.core.cache_service import CacheService
        assert CacheService.make_fingerprint(["a", "b"]) == CacheService.make_fingerprint(["a", "b"])

    def test_order_independent(self):
        from src.app.core.cache_service import CacheService
        assert CacheService.make_fingerprint(["b", "a"]) == CacheService.make_fingerprint(["a", "b"])

    def test_different_roles_differ(self):
        from src.app.core.cache_service import CacheService
        assert CacheService.make_fingerprint(["a"]) != CacheService.make_fingerprint(["b"])

    def test_set_accepted(self):
        from src.app.core.cache_service import CacheService
        assert CacheService.make_fingerprint({"b", "a"}) == CacheService.make_fingerprint(["a", "b"])

    def test_length_is_16(self):
        from src.app.core.cache_service import CacheService
        assert len(CacheService.make_fingerprint(["a"])) == 16


# ═══════════════════════════════════════════════════════════════════
# _get_connection tests
# ═══════════════════════════════════════════════════════════════════

class TestGetConnection:
    def test_finds_connection_in_real_tool(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool()
        conn = CacheService._get_connection(tool)
        assert conn is not None
        assert conn["url"] == "http://mcp-gateway/mcp"

    def test_returns_none_for_no_coroutine(self):
        from src.app.core.cache_service import CacheService

        class Bare:
            coroutine = None
            name = "bare"

        assert CacheService._get_connection(Bare()) is None

    def test_returns_mutable_reference(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool()
        conn = CacheService._get_connection(tool)
        conn["headers"]["injected"] = "yes"
        assert CacheService._get_connection(tool)["headers"]["injected"] == "yes"


# ═══════════════════════════════════════════════════════════════════
# _strip_auth tests
# ═══════════════════════════════════════════════════════════════════

class TestStripAuth:
    def test_removes_authorization_header(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool(headers={"Authorization": "Bearer secret", "X-Keep": "yes"})
        stripped = CacheService._strip_auth([tool], auth_token="secret")
        assert "Authorization" not in _get_headers(stripped[0])
        assert _get_headers(stripped[0])["X-Keep"] == "yes"

    def test_does_not_mutate_original(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool()
        original_headers = dict(_get_headers(tool))
        CacheService._strip_auth([tool], auth_token="token")
        assert _get_headers(tool) == original_headers

    def test_removes_x_auth_token(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool(headers={"x-auth-token": "secret", "x-custom": "keep"})
        stripped = CacheService._strip_auth([tool], auth_token="s")
        assert "x-auth-token" not in _get_headers(stripped[0])
        assert _get_headers(stripped[0])["x-custom"] == "keep"

    def test_handles_no_headers(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool(headers={})
        stripped = CacheService._strip_auth([tool], auth_token="t")
        assert len(stripped) == 1

    def test_handles_empty_list(self):
        from src.app.core.cache_service import CacheService
        assert CacheService._strip_auth([], auth_token="t") == []


# ═══════════════════════════════════════════════════════════════════
# _inject_auth tests
# ═══════════════════════════════════════════════════════════════════

class TestInjectAuth:
    def test_injects_authorization_header(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool(headers={})
        CacheService._inject_auth([tool], auth_token="fresh-jwt")
        assert _get_headers(tool)["Authorization"] == "Bearer fresh-jwt"

    def test_replaces_existing_token(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool(headers={"Authorization": "Bearer stale"})
        CacheService._inject_auth([tool], auth_token="fresh")
        assert _get_headers(tool)["Authorization"] == "Bearer fresh"

    def test_preserves_non_auth_headers(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool(headers={"X-Tenant": "abc"})
        CacheService._inject_auth([tool], auth_token="t")
        assert _get_headers(tool)["X-Tenant"] == "abc"
        assert _get_headers(tool)["Authorization"] == "Bearer t"


# ═══════════════════════════════════════════════════════════════════
# _serialise / _deserialise tests
# ═══════════════════════════════════════════════════════════════════

class TestSerialiseDeserialise:
    def test_round_trip_preserves_name(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool(name="my_tool")
        blob = CacheService._serialise([tool])
        restored = CacheService._deserialise(blob)
        assert restored[0].name == "my_tool"

    def test_round_trip_preserves_description(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool()
        blob = CacheService._serialise([tool])
        restored = CacheService._deserialise(blob)
        assert restored[0].description == tool.description

    def test_serialise_multiple_tools(self):
        from src.app.core.cache_service import CacheService
        tools = [_make_tool(name=f"t{i}") for i in range(4)]
        blob = CacheService._serialise(tools)
        restored = CacheService._deserialise(blob)
        assert [t.name for t in restored] == [f"t{i}" for i in range(4)]

    def test_deserialise_corrupt_raises(self):
        from src.app.core.cache_service import CacheService
        from src.app.exceptions.cache_exceptions import CacheDeserialiseError
        with pytest.raises(CacheDeserialiseError) as exc_info:
            CacheService._deserialise(b"not-valid-dill")
        assert exc_info.value.error_code == "AAPMDC_CACHE_DESERIALISE_FAILED"

    def test_blob_does_not_contain_auth_token_after_strip(self):
        from src.app.core.cache_service import CacheService
        tool = _make_tool()
        stripped = CacheService._strip_auth([tool], auth_token="super-secret")
        blob = CacheService._serialise(stripped)
        assert b"super-secret" not in blob


# ═══════════════════════════════════════════════════════════════════
# CacheService.get_tools tests
# ═══════════════════════════════════════════════════════════════════

class TestCacheServiceGetTools:
    @pytest.mark.asyncio
    async def test_returns_none_on_miss(self, cache_service, mock_redis):
        mock_redis.get_bytes = AsyncMock(return_value=None)
        result = await cache_service.get_tools(["ns_a"], auth_token="t")
        assert result is None

    @pytest.mark.asyncio
    async def test_returns_tools_on_hit(self, cache_service, mock_redis):
        from src.app.core.cache_service import CacheService
        tool = _make_tool()
        stripped = CacheService._strip_auth([tool], auth_token="old")
        blob = CacheService._serialise(stripped)
        mock_redis.get_bytes = AsyncMock(return_value=blob)

        result = await cache_service.get_tools(["ns_a"], auth_token="fresh")
        assert result is not None
        assert result[0].name == "query_data"

    @pytest.mark.asyncio
    async def test_injects_fresh_token_on_hit(self, cache_service, mock_redis):
        from src.app.core.cache_service import CacheService
        tool = _make_tool()
        stripped = CacheService._strip_auth([tool], auth_token="old")
        blob = CacheService._serialise(stripped)
        mock_redis.get_bytes = AsyncMock(return_value=blob)

        result = await cache_service.get_tools(["ns_a"], auth_token="brand-new")
        assert _get_headers(result[0])["Authorization"] == "Bearer brand-new"

    @pytest.mark.asyncio
    async def test_evicts_corrupt_blob(self, cache_service, mock_redis):
        mock_redis.get_bytes = AsyncMock(return_value=b"garbage")
        result = await cache_service.get_tools(["ns_a"], auth_token="t")
        assert result is None
        mock_redis.delete.assert_called_once()

    @pytest.mark.asyncio
    async def test_fail_open_on_redis_error(self, cache_service, mock_redis):
        mock_redis.get_bytes = AsyncMock(side_effect=ConnectionError("Redis down"))
        result = await cache_service.get_tools(["ns_a"], auth_token="t")
        assert result is None  # no exception raised


# ═══════════════════════════════════════════════════════════════════
# CacheService.set_tools tests
# ═══════════════════════════════════════════════════════════════════

class TestCacheServiceSetTools:
    @pytest.mark.asyncio
    async def test_sets_blob_with_correct_ttl(self, cache_service, mock_redis):
        tool = _make_tool()
        await cache_service.set_tools(["ns_a"], [tool], auth_token="t")
        mock_redis.set_bytes.assert_called_once()
        call_kwargs = mock_redis.set_bytes.call_args.kwargs
        assert call_kwargs["ttl_seconds"] == 300

    @pytest.mark.asyncio
    async def test_key_starts_with_prefix(self, cache_service, mock_redis):
        from src.app.core.cache_service import TOOL_CACHE_KEY_PREFIX
        tool = _make_tool()
        await cache_service.set_tools(["ns_a"], [tool], auth_token="t")
        stored_key = mock_redis.set_bytes.call_args.args[0]
        assert stored_key.startswith(TOOL_CACHE_KEY_PREFIX)

    @pytest.mark.asyncio
    async def test_stored_blob_has_no_auth_token(self, cache_service, mock_redis):
        tool = _make_tool()
        await cache_service.set_tools(["ns_a"], [tool], auth_token="do-not-store-this")
        stored_blob = mock_redis.set_bytes.call_args.args[1]
        assert b"do-not-store-this" not in stored_blob

    @pytest.mark.asyncio
    async def test_skips_empty_tools(self, cache_service, mock_redis):
        await cache_service.set_tools(["ns_a"], [], auth_token="t")
        mock_redis.set_bytes.assert_not_called()

    @pytest.mark.asyncio
    async def test_fail_open_on_redis_error(self, cache_service, mock_redis):
        mock_redis.set_bytes = AsyncMock(side_effect=ConnectionError("down"))
        tool = _make_tool()
        await cache_service.set_tools(["ns_a"], [tool], auth_token="t")
        # no exception raised


# ═══════════════════════════════════════════════════════════════════
# CacheService.invalidate / invalidate_all tests
# ═══════════════════════════════════════════════════════════════════

class TestCacheServiceInvalidate:
    @pytest.mark.asyncio
    async def test_invalidate_calls_delete_with_correct_key(self, cache_service, mock_redis):
        from src.app.core.cache_service import CacheService, TOOL_CACHE_KEY_PREFIX
        await cache_service.invalidate(["ns_a"])
        deleted_key = mock_redis.delete.call_args.args[0]
        assert deleted_key == TOOL_CACHE_KEY_PREFIX + CacheService.make_fingerprint(["ns_a"])

    @pytest.mark.asyncio
    async def test_invalidate_all_calls_scan_delete(self, cache_service, mock_redis):
        from src.app.core.cache_service import TOOL_CACHE_KEY_PATTERN
        await cache_service.invalidate_all()
        mock_redis.scan_delete.assert_called_once_with(TOOL_CACHE_KEY_PATTERN)


# ═══════════════════════════════════════════════════════════════════
# Token lifecycle integration test (end-to-end with in-memory Redis)
# ═══════════════════════════════════════════════════════════════════

class TestTokenLifecycle:
    @pytest.fixture
    def svc(self, in_memory_redis):
        from src.app.core.cache_service import CacheService, CacheSettings
        return CacheService(
            redis_client=in_memory_redis,
            settings=CacheSettings(tool_cache_ttl_seconds=300),
        )

    @pytest.mark.asyncio
    async def test_write_and_read_with_fresh_token(self, svc):
        tool = _make_tool()
        roles = ["ns_a", "ns_b"]

        await svc.set_tools(roles, [tool], auth_token="jwt-v1")
        result = await svc.get_tools(roles, auth_token="jwt-v2")

        assert result is not None
        assert _get_headers(result[0])["Authorization"] == "Bearer jwt-v2"

    @pytest.mark.asyncio
    async def test_stored_blob_is_token_free(self, svc, in_memory_redis):
        tool = _make_tool()
        await svc.set_tools(["ns_a"], [tool], auth_token="secret-jwt")

        stored = list(vars(in_memory_redis).get("store", {}).values()) if hasattr(in_memory_redis, "store") else []
        # Access via the fixture's internal store dict directly
        store = {}
        _orig_set = in_memory_redis.set_bytes
        captured = {}

        async def capture_set(key, value, *, ttl_seconds):
            captured[key] = value
            return True

        in_memory_redis.set_bytes = capture_set
        await svc.set_tools(["ns_b"], [tool], auth_token="another-secret")
        in_memory_redis.set_bytes = _orig_set

        for blob in captured.values():
            assert b"another-secret" not in blob

    @pytest.mark.asyncio
    async def test_different_roles_get_different_keys(self, svc):
        tool_a = _make_tool(name="tool_a")
        tool_b = _make_tool(name="tool_b")

        await svc.set_tools(["ns_a"], [tool_a], auth_token="t")
        await svc.set_tools(["ns_b"], [tool_b], auth_token="t")

        result_a = await svc.get_tools(["ns_a"], auth_token="fresh")
        result_b = await svc.get_tools(["ns_b"], auth_token="fresh")

        assert result_a[0].name == "tool_a"
        assert result_b[0].name == "tool_b"

    @pytest.mark.asyncio
    async def test_multiple_token_refreshes(self, svc):
        tool = _make_tool()
        roles = ["ns_x"]

        await svc.set_tools(roles, [tool], auth_token="v1")

        for version in ["v2", "v3", "v4"]:
            result = await svc.get_tools(roles, auth_token=version)
            assert _get_headers(result[0])["Authorization"] == f"Bearer {version}"

    @pytest.mark.asyncio
    async def test_invalidate_causes_miss(self, svc):
        tool = _make_tool()
        roles = ["ns_y"]

        await svc.set_tools(roles, [tool], auth_token="t")
        assert await svc.get_tools(roles, auth_token="t") is not None

        await svc.invalidate(roles)
        assert await svc.get_tools(roles, auth_token="t") is None
