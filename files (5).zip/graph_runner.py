"""
app/core/graph_runner.py

GraphRunner — launches LangGraph tasks and writes events to the thread's
Redis Stream.

FLOW
====

POST /assist → start_turn() → background asyncio.Task → returns immediately
Background task runs graph → writes events to Redis Stream (XADD)
GET /events/{thread_id} → XREAD BLOCK → SSE to browser (any pod)

The emitter closure (emit_elicitation) writes elicitation events to
the Redis Stream instead of an in-process queue. The result is the same
from the perspective of on_elicitation — it calls await emitter(request)
and the event appears on the SSE stream.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from app.core.elicitation_bridge import ElicitationBridge
from app.core.mcp_session_manager import (
    MCPSessionManager,
    current_session_id,
    elicitation_event_emitter,
)
from app.core.session_event_store import ThreadEventStore
from app.models.state import ElicitationRequest, GraphState

logger = logging.getLogger(__name__)


class GraphRunner:
    """
    Manages LangGraph graph tasks for the /assist pipeline.

    start_turn()  — fires background task, returns immediately (202 pattern)
    All events    — written to Redis Stream via ThreadEventStore
    """

    def __init__(
        self,
        compiled_graph:        Any,
        bridge:                ElicitationBridge,
        mcp_manager:           MCPSessionManager,
        event_store:           ThreadEventStore,
        notification_listener: Any | None = None,
    ) -> None:
        self._graph                 = compiled_graph
        self._bridge                = bridge
        self._mcp_manager           = mcp_manager
        self._event_store           = event_store
        self._notification_listener = notification_listener
        # (thread_id, turn_id) → asyncio.Task
        self._active_tasks: dict[tuple[str, str], asyncio.Task] = {}

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    async def start_turn(
        self,
        thread_id:    str,
        turn_id:      str,
        user_input:   str,
        bearer_token: str,
    ) -> None:
        """
        Launch a background graph task for one user message.
        Returns immediately — caller responds HTTP 202.

        Raises ValueError if this (thread_id, turn_id) is already running
        (duplicate POST — client should check for 409 and not retry blindly).
        """
        key = (thread_id, turn_id)
        if key in self._active_tasks and not self._active_tasks[key].done():
            raise ValueError(
                f"Turn {turn_id} already running for thread {thread_id}"
            )

        task = asyncio.create_task(
            self._graph_task(thread_id, turn_id, user_input, bearer_token),
            name=f"graph-{thread_id[:8]}-{turn_id[:8]}",
        )
        self._active_tasks[key] = task
        task.add_done_callback(lambda t: self._active_tasks.pop(key, None))
        logger.info("Graph task started: thread=%s turn=%s", thread_id[:8], turn_id[:8])

    def resolve_elicitation(
        self,
        session_id:     str,
        elicitation_id: str,
        action:         str,
        content:        dict | None = None,
    ) -> bool:
        """
        Resolve a pending elicitation Future.
        session_id here is thread_id — same concept, different layer name.
        In distributed mode the bridge publishes to Redis.
        """
        return self._bridge.resolve(
            session_id=session_id,
            elicitation_id=elicitation_id,
            action=action,
            content=content,
        )

    def is_running(self, thread_id: str, turn_id: str) -> bool:
        task = self._active_tasks.get((thread_id, turn_id))
        return task is not None and not task.done()

    async def stop(self) -> None:
        for task in self._active_tasks.values():
            if not task.done():
                task.cancel()
        self._active_tasks.clear()

    # -------------------------------------------------------------------------
    # Private: graph task
    # -------------------------------------------------------------------------

    async def _graph_task(
        self,
        thread_id:    str,
        turn_id:      str,
        user_input:   str,
        bearer_token: str,
    ) -> None:
        """
        Background task: run graph, write all events to Redis Stream.

        The elicitation emitter writes to the thread stream so the
        SSE connection on any pod receives the elicitation event.
        """
        # ElicitationBridge uses "session_id" — thread_id is our session_id
        sid_token  = current_session_id.set(thread_id)
        emit_token = None

        try:
            async def emit_elicitation(request: ElicitationRequest) -> None:
                """Called by on_elicitation when a tool triggers elicitation."""
                await self._event_store.append(
                    thread_id=thread_id,
                    turn_id=turn_id,
                    event_type="elicitation",
                    payload={
                        "elicitation_id": request.elicitation_id,
                        "mode":           request.mode.value,
                        "message":        request.message,
                        "schema":         request.schema,
                        "url":            request.url,
                        "tool_name":      getattr(request, "tool_name", ""),
                    },
                )

            emit_token = elicitation_event_emitter.set(emit_elicitation)

            tools      = await self._mcp_manager.get_tools(bearer_token)
            mcp_client = self._mcp_manager.build_client(bearer_token)

            initial_state = GraphState(
                session_id=thread_id,
                user_input=user_input,
                messages=[],
                tool_results=[],
                node_trace=[],
                is_safe=True,
            )

            config = {
                "configurable": {
                    "thread_id":             thread_id,
                    "mcp_client":            mcp_client,
                    "mcp_tools":             tools,
                    "elicitation_bridge":    self._bridge,
                    "bearer_token":          bearer_token,
                    "notification_listener": self._notification_listener,
                }
            }

            async with mcp_client:
                async for event in self._graph.astream_events(
                    initial_state, config=config, version="v2"
                ):
                    await self._handle_graph_event(thread_id, turn_id, event)

            # Retrieve final answer from LangGraph checkpoint
            snapshot     = await self._graph.aget_state(config)
            final_state  = snapshot.values if snapshot else None
            final_answer = getattr(final_state, "final_answer", "") if final_state else ""
            node_trace   = getattr(final_state, "node_trace", []) if final_state else []

            await self._event_store.mark_turn_complete(
                thread_id=thread_id,
                turn_id=turn_id,
                answer=final_answer,
                metadata={"node_trace": node_trace},
            )
            logger.info("Graph task complete: thread=%s turn=%s", thread_id[:8], turn_id[:8])

        except asyncio.CancelledError:
            await self._event_store.mark_turn_error(thread_id, turn_id, "Cancelled")
            raise

        except Exception as exc:
            logger.exception("Graph task error: thread=%s turn=%s", thread_id[:8], turn_id[:8])
            try:
                await self._event_store.mark_turn_error(thread_id, turn_id, str(exc))
            except Exception:
                pass

        finally:
            current_session_id.reset(sid_token)
            if emit_token is not None:
                elicitation_event_emitter.reset(emit_token)

    async def _handle_graph_event(
        self, thread_id: str, turn_id: str, event: dict
    ) -> None:
        """Translate a LangGraph astream_events event into a Redis Stream entry."""
        kind = event.get("event", "")
        name = event.get("name", "")
        node_names = {
            "guardrail_node", "query_rephrase_node",
            "mcp_node", "answer_generation_node",
        }

        if kind == "on_chain_start" and name in node_names:
            await self._event_store.append(
                thread_id, turn_id, "node_start", {"node": name}
            )
        elif kind == "on_chain_end" and name in node_names:
            await self._event_store.append(
                thread_id, turn_id, "node_complete", {"node": name}
            )
        elif kind == "on_chat_model_stream":
            chunk   = event.get("data", {}).get("chunk")
            content = getattr(chunk, "content", "") if chunk else ""
            if content:
                await self._event_store.append(
                    thread_id, turn_id, "token", {"content": content}
                )
