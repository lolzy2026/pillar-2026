#!/usr/bin/env python3
"""
local_test.py

Interactive end-to-end test for the MCP Assist Service.

Tests the full flow:
  1. POST /assist → 202
  2. GET /events/{thread_id} → SSE stream opens
  3. Events stream: node_start, node_complete, token, complete
  4. If elicitation arrives: display URL, wait for user to complete it,
     POST /assist with is_elicitation_response=True
  5. SSE stream resumes with final answer

USAGE
=====

  # Normal message (no elicitation expected):
  python local_test.py "What files are in my GitHub repo?"

  # Message that triggers URL elicitation:
  python local_test.py "Login to server v2"

  # With custom thread (continue an existing conversation):
  THREAD_ID=abc-123 python local_test.py "Follow up question"

ENVIRONMENT
===========
  BASE_URL      default: http://localhost:8000
  BEARER_TOKEN  default: test-token
  THREAD_ID     default: auto-generated UUID
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import uuid
from datetime import datetime

import httpx


BASE_URL     = os.getenv("BASE_URL", "http://localhost:8000")
BEARER_TOKEN = os.getenv("BEARER_TOKEN", "test-token")
THREAD_ID    = os.getenv("THREAD_ID", str(uuid.uuid4()))
TURN_ID      = str(uuid.uuid4())

HEADERS = {
    "Authorization": f"Bearer {BEARER_TOKEN}",
    "Content-Type":  "application/json",
}


def ts() -> str:
    return datetime.now().strftime("%H:%M:%S.%f")[:-3]


def print_event(event: dict) -> None:
    t    = event.get("type", "")
    tid  = event.get("turn_id", "")[:8]
    pay  = event.get("payload", {})

    colours = {
        "node_start":    "\033[36m",   # cyan
        "node_complete": "\033[32m",   # green
        "token":         "\033[33m",   # yellow
        "elicitation":   "\033[35m",   # magenta
        "complete":      "\033[92m",   # bright green
        "error":         "\033[91m",   # bright red
    }
    reset = "\033[0m"
    colour = colours.get(t, "")

    if t == "token":
        print(pay.get("content", ""), end="", flush=True)
    elif t == "complete":
        print(f"\n{colour}[{ts()}][{tid}] COMPLETE{reset}")
        print(f"  Answer: {pay.get('answer', '')[:200]}")
    elif t == "elicitation":
        print(f"\n{colour}[{ts()}][{tid}] ELICITATION{reset}")
        print(f"  Mode:    {pay.get('mode')}")
        print(f"  Message: {pay.get('message')}")
        if pay.get("url"):
            print(f"  URL:     {pay.get('url')}")
        if pay.get("schema"):
            print(f"  Schema:  {json.dumps(pay.get('schema'), indent=4)}")
    elif t == "error":
        print(f"\n{colour}[{ts()}][{tid}] ERROR: {pay.get('message')}{reset}")
    else:
        print(f"{colour}[{ts()}][{tid}] {t.upper()}: {json.dumps(pay)}{reset}")


async def post_assist(message: str) -> dict:
    """POST /assist with a new message. Returns the 202 body."""
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.post(
            f"{BASE_URL}/api/v1/assist",
            headers=HEADERS,
            json={
                "thread_id": THREAD_ID,
                "turn_id":   TURN_ID,
                "message":   message,
            },
        )
        resp.raise_for_status()
        return resp.json()


async def post_elicitation_response(
    elicitation_id: str,
    action: str = "accept",
    content: dict | None = None,
) -> dict:
    """POST /assist with an elicitation response."""
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.post(
            f"{BASE_URL}/api/v1/assist",
            headers=HEADERS,
            json={
                "thread_id":               THREAD_ID,
                "turn_id":                 TURN_ID,
                "is_elicitation_response": True,
                "elicitation_id":          elicitation_id,
                "elicitation_action":      action,
                "elicitation_content":     content or {},
            },
        )
        resp.raise_for_status()
        return resp.json()


async def stream_events() -> None:
    """
    Open GET /events/{thread_id} and process events until turn completes.
    Handles elicitation interactively.
    """
    url     = f"{BASE_URL}/api/v1/events/{THREAD_ID}"
    cursor  = "0-0"
    done    = False

    print(f"\033[90m[{ts()}] Opening SSE stream: {url}\033[0m")

    async with httpx.AsyncClient(timeout=None) as client:
        async with client.stream("GET", url, headers=HEADERS,
                                 params={"cursor": cursor}) as resp:
            resp.raise_for_status()
            buffer = ""

            async for chunk in resp.aiter_text():
                buffer += chunk
                while "\n\n" in buffer:
                    event_str, buffer = buffer.split("\n\n", 1)
                    lines = event_str.strip().splitlines()

                    entry_id = None
                    data_str = None
                    for line in lines:
                        if line.startswith("id: "):
                            entry_id = line[4:]
                        elif line.startswith("data: "):
                            data_str = line[6:]

                    if not data_str:
                        continue

                    try:
                        event = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    print_event(event)

                    # Handle elicitation interactively
                    if event.get("type") == "elicitation":
                        payload = event.get("payload", {})
                        elicitation_id = payload.get("elicitation_id")
                        mode           = payload.get("mode")

                        if mode == "url":
                            url_to_open = payload.get("url", "")
                            print(f"\n\033[93m{'='*60}")
                            print(f"  ACTION REQUIRED")
                            print(f"  Open this URL and complete the flow:")
                            print(f"  {url_to_open}")
                            print(f"{'='*60}\033[0m")
                            input("  Press ENTER after completing the URL flow... ")
                            print(f"\033[90m[{ts()}] Sending elicitation response...\033[0m")
                            ack = await post_elicitation_response(elicitation_id)
                            print(f"\033[90m[{ts()}] ACK: {ack}\033[0m")

                        elif mode == "form":
                            schema  = payload.get("schema", {})
                            props   = schema.get("properties", {})
                            content = {}
                            print(f"\n\033[93m{'='*60}")
                            print(f"  FORM REQUIRED: {payload.get('message')}")
                            for field, spec in props.items():
                                val = input(f"  {spec.get('title', field)}: ")
                                content[field] = val
                            print(f"{'='*60}\033[0m")
                            ack = await post_elicitation_response(
                                elicitation_id, action="accept", content=content
                            )
                            print(f"\033[90m[{ts()}] ACK: {ack}\033[0m")

                    if event.get("type") == "complete":
                        done = True
                        break

                if done:
                    break


async def check_health() -> None:
    async with httpx.AsyncClient(timeout=5) as client:
        try:
            resp = await client.get(f"{BASE_URL}/health")
            data = resp.json()
            print(f"\033[90m[{ts()}] Health: {data}\033[0m")
        except Exception as exc:
            print(f"\033[91m[{ts()}] Health check failed: {exc}\033[0m")
            sys.exit(1)


async def main() -> None:
    message = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "What can you help me with?"

    print(f"\033[1mMCP Assist Local Test\033[0m")
    print(f"  Base URL:  {BASE_URL}")
    print(f"  Thread ID: {THREAD_ID}")
    print(f"  Turn ID:   {TURN_ID}")
    print(f"  Message:   {message}\n")

    await check_health()

    print(f"\033[90m[{ts()}] Sending message...\033[0m")
    resp_202 = await post_assist(message)
    print(f"\033[90m[{ts()}] 202 response: {resp_202}\033[0m")

    await stream_events()
    print(f"\n\033[90m[{ts()}] Done.\033[0m\n")


if __name__ == "__main__":
    asyncio.run(main())
