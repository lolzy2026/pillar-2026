"""
app/core/notification_listener.py

NotificationListener — dedicated persistent MCP SSE connection that listens
for server notifications, specifically notifications/elicitation/complete.

WHY THIS IS NECESSARY
=====================

There are two elicitation patterns:

  Pattern 1 — ctx.elicit() / ctx.elicit_url():
    The tool SUSPENDS mid-execution. The per-request MCP SSE connection stays
    alive while the tool is suspended. When the user completes the URL flow,
    the MCP server sends notifications/elicitation/complete on THAT connection.
    MCPSessionManager._on_notification() handles it transparently.

  Pattern 2 — raise UrlElicitationRequiredError (-32042):
    The tool TERMINATES immediately. The per-request MCP SSE connection is
    CLOSED before the user even sees the URL. When the user completes the OAuth
    flow later, the server sends notifications/elicitation/complete — but there
    is no per-request connection to receive it on.

The NotificationListener maintains a separate, long-lived SSE connection to
the MCP server for the sole purpose of receiving these completion notifications
and routing them to the ElicitationBridge.

ARCHITECTURE
============

  App startup: NotificationListener connects and starts listening.

  Per-token connections:
    Each bearer token that has an active elicitation gets its own listener
    connection. The MCP server routes notifications to the correct client
    based on the bearer token, so we need a connection per token.

    For simplicity, this implementation maintains ONE listener per unique
    bearer token hash. When a user starts a URL elicitation, their token is
    registered with the listener. The listener opens a connection if one
    doesn't exist yet.

  Reconnection:
    On disconnect, the listener uses exponential backoff to reconnect.
    While disconnected, completions are covered by Path B (manual user POST).
    Reconnection is transparent to the elicitation flow.

  Clean shutdown:
    All connections are closed gracefully in stop().

DESIGN DECISION: Separate connection vs reusing tool-call connection
====================================================================

We intentionally use a SEPARATE connection rather than trying to keep the
tool-call connection alive across the -32042 error. Reasons:

  1. The -32042 error terminates the tool call at the protocol level.
     The SDK closes the session. We cannot override this.
  2. A separate connection is cleaner: it is not tied to any specific tool
     call, can survive across multiple tool calls, and is managed independently.
  3. The MCP server sends notifications to the correct client based on the
     bearer token, so a separate connection with the same token works.

NOTIFICATION PAYLOAD (MCP spec)
================================

{
  "jsonrpc": "2.0",
  "method": "notifications/elicitation/complete",
  "params": {
    "elicitationId": "550e8400-e29b-41d4-a716-446655440000"
  }
}
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone

from app.core.elicitation_bridge import ElicitationBridge

logger = logging.getLogger(__name__)

# Reconnection backoff: 1s, 2s, 4s, 8s, 16s, 30s (max)
_BACKOFF_INITIAL = 1.0
_BACKOFF_MAX     = 30.0
_BACKOFF_FACTOR  = 2.0

# How long to keep a listener connection alive after the last active elicitation
# for its token (prevents churn from short-lived tokens)
_IDLE_KEEPALIVE_SECONDS = 120


@dataclass
class _ListenerConnection:
    """Tracks one persistent connection for a given (hashed) bearer token."""
    token_hash:   str
    bearer_token: str
    task:         asyncio.Task
    created_at:   datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_active:  datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    connected:    bool = False
    reconnects:   int = 0


class NotificationListener:
    """
    Maintains per-token persistent MCP SSE connections for receiving
    notifications/elicitation/complete events (Path A, Pattern 2).

    Usage (FastAPI lifespan):
        listener = NotificationListener(
            server_url=mcp_server_url,
            bridge=bridge,
        )
        await listener.start()
        ...
        await listener.stop()

    Usage (when a URL elicitation starts):
        listener.ensure_listening(bearer_token)
        # Call this from url_elicitation_handler or mcp_node when a
        # UrlElicitationRequiredError is caught, BEFORE awaiting the Future.
    """

    def __init__(
        self,
        server_url:  str,
        bridge:      ElicitationBridge,
        server_name: str = "default",
        transport:   str = "streamable_http",
    ) -> None:
        self._server_url  = server_url
        self._bridge      = bridge
        self._server_name = server_name
        self._transport   = transport

        # token_hash → _ListenerConnection
        self._connections: dict[str, _ListenerConnection] = {}
        self._lock = asyncio.Lock()
        self._stopped = False

    # =========================================================================
    # Lifecycle
    # =========================================================================

    async def start(self) -> None:
        """Start the listener. Call from FastAPI lifespan."""
        self._stopped = False
        logger.info(
            "NotificationListener started: server=%s transport=%s",
            self._server_url, self._transport,
        )

    async def stop(self) -> None:
        """Stop all listener connections gracefully."""
        self._stopped = True
        async with self._lock:
            for conn in list(self._connections.values()):
                if not conn.task.done():
                    conn.task.cancel()
            self._connections.clear()
        logger.info("NotificationListener stopped")

    # =========================================================================
    # Public API
    # =========================================================================

    def ensure_listening(self, bearer_token: str) -> None:
        """
        Ensure a persistent notification listener is running for this token.

        Call this from url_elicitation_handler when a -32042 error is caught,
        BEFORE awaiting the Future. This guarantees the listener is in place
        before the OAuth callback can fire.

        Non-blocking — spawns a background task if needed.
        """
        import hashlib
        token_hash = hashlib.sha256(bearer_token.encode()).hexdigest()

        conn = self._connections.get(token_hash)
        if conn and not conn.task.done():
            # Already listening
            conn.last_active = datetime.now(timezone.utc)
            logger.debug("NotificationListener: already listening for token %s...", token_hash[:8])
            return

        logger.info(
            "NotificationListener: starting listener for token %s...", token_hash[:8]
        )
        task = asyncio.create_task(
            self._listen_loop(bearer_token, token_hash),
            name=f"notif-listener-{token_hash[:8]}",
        )
        self._connections[token_hash] = _ListenerConnection(
            token_hash=token_hash,
            bearer_token=bearer_token,
            task=task,
        )

    def mark_active(self, bearer_token: str) -> None:
        """Update last_active timestamp for a token's listener."""
        import hashlib
        token_hash = hashlib.sha256(bearer_token.encode()).hexdigest()
        conn = self._connections.get(token_hash)
        if conn:
            conn.last_active = datetime.now(timezone.utc)

    def listener_count(self) -> int:
        return len(self._connections)

    # =========================================================================
    # Private: listener loop per token
    # =========================================================================

    async def _listen_loop(self, bearer_token: str, token_hash: str) -> None:
        """
        Background task that maintains a persistent MCP SSE connection for
        one bearer token and routes notifications to the bridge.

        Reconnects with exponential backoff on disconnect.
        Stops when:
          - NotificationListener.stop() is called (self._stopped=True)
          - The task is cancelled
          - No elicitations have been active for _IDLE_KEEPALIVE_SECONDS
        """
        backoff = _BACKOFF_INITIAL

        while not self._stopped:
            try:
                await self._run_single_connection(bearer_token, token_hash)

                # Clean exit from _run_single_connection means we should stop
                # (either stopped flag or idle timeout)
                if self._stopped:
                    break

                # Check idle: if no active elicitations for this token recently,
                # shut down the listener to free resources
                conn = self._connections.get(token_hash)
                if conn:
                    idle_secs = (
                        datetime.now(timezone.utc) - conn.last_active
                    ).total_seconds()
                    if idle_secs > _IDLE_KEEPALIVE_SECONDS:
                        logger.info(
                            "NotificationListener: idle timeout for token %s... "
                            "— shutting down listener",
                            token_hash[:8],
                        )
                        break

                # Reconnect after a clean disconnect
                logger.info(
                    "NotificationListener: connection ended cleanly for token %s..., "
                    "reconnecting in %.1fs",
                    token_hash[:8], backoff,
                )
                await asyncio.sleep(backoff)

            except asyncio.CancelledError:
                break

            except Exception as exc:
                if self._stopped:
                    break
                conn = self._connections.get(token_hash)
                reconnects = conn.reconnects if conn else 0
                logger.warning(
                    "NotificationListener: connection error for token %s... "
                    "(attempt %d): %s — retrying in %.1fs",
                    token_hash[:8], reconnects + 1, exc, backoff,
                )
                if conn:
                    conn.connected = False
                    conn.reconnects += 1

                await asyncio.sleep(backoff)
                backoff = min(backoff * _BACKOFF_FACTOR, _BACKOFF_MAX)
                continue

            # Reset backoff on clean reconnect
            backoff = _BACKOFF_INITIAL

        # Clean up the connection entry
        async with self._lock:
            self._connections.pop(token_hash, None)
        logger.debug(
            "NotificationListener: listener task exited for token %s...", token_hash[:8]
        )

    async def _run_single_connection(
        self,
        bearer_token: str,
        token_hash:   str,
    ) -> None:
        """
        Open one MCP connection and process notifications until disconnected.

        Uses langchain-mcp-adapters MultiServerMCPClient with only
        on_notification wired — this connection is notification-only, not
        used for tool execution.
        """
        # Import here to avoid circular imports
        from langchain_mcp_adapters.client import MultiServerMCPClient  # type: ignore

        conn = self._connections.get(token_hash)

        async def _on_notification(notification, callback_context) -> None:
            """Route received notifications to the bridge."""
            method = getattr(notification, "method", None) or ""
            params = getattr(notification, "params", None) or {}

            if method != "notifications/elicitation/complete":
                logger.debug(
                    "NotificationListener: ignoring non-elicitation notification: %s",
                    method,
                )
                return

            elicitation_id = (
                getattr(params, "elicitationId", None)
                or getattr(params, "elicitation_id", None)
                or (params.get("elicitationId") if isinstance(params, dict) else None)
            )

            if not elicitation_id:
                logger.warning(
                    "NotificationListener: notifications/elicitation/complete "
                    "missing elicitationId: params=%s", params,
                )
                return

            logger.info(
                "NotificationListener: received completion notification: id=%s",
                elicitation_id,
            )

            # Update activity timestamp
            if conn:
                conn.last_active = datetime.now(timezone.utc)

            # Route to bridge (Path A)
            resolved = await self._bridge.resolve_from_notification(elicitation_id)

            if resolved:
                logger.info(
                    "NotificationListener: Future resolved via notification: id=%s",
                    elicitation_id,
                )
            else:
                logger.debug(
                    "NotificationListener: notification not resolved locally "
                    "(may be on another worker or RC-1 parked): id=%s",
                    elicitation_id,
                )

        client = MultiServerMCPClient(
            {
                self._server_name: {
                    "url": self._server_url,
                    "transport": self._transport,
                    "headers": {
                        "Authorization": f"Bearer {bearer_token}",
                    },
                }
            },
            callbacks={"on_notification": _on_notification},
        )

        if conn:
            conn.connected = True

        logger.debug(
            "NotificationListener: connection established for token %s...",
            token_hash[:8],
        )

        # Open the connection and hold it open.
        # The client context manager keeps the SSE connection alive until
        # the context exits (on disconnect, stop, or cancellation).
        async with client:
            # Keep connection alive — notifications arrive via _on_notification callback.
            # We poll for the stop signal and idle timeout rather than blocking forever,
            # so that clean shutdown and idle eviction work correctly.
            while not self._stopped:
                await asyncio.sleep(5)

                # Idle check
                if conn:
                    idle_secs = (
                        datetime.now(timezone.utc) - conn.last_active
                    ).total_seconds()
                    if idle_secs > _IDLE_KEEPALIVE_SECONDS:
                        logger.info(
                            "NotificationListener: idle — closing connection "
                            "for token %s...", token_hash[:8],
                        )
                        return  # exits context manager → connection closed cleanly
