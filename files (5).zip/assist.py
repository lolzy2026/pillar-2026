"""
app/api/assist.py

POST /api/v1/assist

Two routes:

  Route A — New user message:
    Launches background graph task. Returns 202 immediately.
    Client reads events from GET /api/v1/events/{thread_id}.

  Route B — Elicitation response:
    Resolves the pending Future for this elicitation.
    Returns 200 ACK. The SSE stream updates automatically.

REQUEST BODY

  Normal message:
    {
      "thread_id": "stable-conversation-id",
      "turn_id":   "client-generated-uuid",
      "message":   "Login to my GitHub account"
    }

  Elicitation response:
    {
      "thread_id":               "stable-conversation-id",
      "turn_id":                 "same-turn-id-as-original",
      "is_elicitation_response": true,
      "elicitation_id":          "from-elicitation-event",
      "elicitation_action":      "accept",
      "elicitation_content":     {"field": "value"}
    }

WHY CLIENT GENERATES turn_id
  1. Idempotency: retried POSTs with the same turn_id return 409 instead
     of launching a duplicate graph task.
  2. Attribution: client knows which message bubble owns incoming tokens
     before the server responds.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.core.graph_runner import GraphRunner
from app.models.api import AssistRequest

logger  = logging.getLogger(__name__)
router  = APIRouter()
_bearer = HTTPBearer()


def _get_token(creds: HTTPAuthorizationCredentials = Depends(_bearer)) -> str:
    return creds.credentials


@router.post("/assist")
async def assist(
    body:         AssistRequest,
    request:      Request,
    bearer_token: str = Depends(_get_token),
):
    runner: GraphRunner = request.app.state.graph_runner

    # ── Route B: elicitation response ────────────────────────────────────────
    if body.is_elicitation_response:
        if not body.elicitation_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="elicitation_id required when is_elicitation_response=True",
            )

        resolved = runner.resolve_elicitation(
            session_id=body.thread_id,
            elicitation_id=body.elicitation_id,
            action=body.elicitation_action or "accept",
            content=body.elicitation_content or {},
        )

        # Always 200 — idempotent (RC-2/RC-3: may already be resolved)
        return JSONResponse({
            "status":         "accepted",
            "thread_id":      body.thread_id,
            "elicitation_id": body.elicitation_id,
            "resolved":       resolved,
        })

    # ── Route A: new user message ─────────────────────────────────────────────
    if not body.message:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="message is required for new requests",
        )

    try:
        await runner.start_turn(
            thread_id=body.thread_id,
            turn_id=body.turn_id,
            user_input=body.message,
            bearer_token=bearer_token,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        )

    return JSONResponse(
        status_code=status.HTTP_202_ACCEPTED,
        content={
            "status":     "started",
            "thread_id":  body.thread_id,
            "turn_id":    body.turn_id,
            "events_url": f"/api/v1/events/{body.thread_id}",
        },
    )
