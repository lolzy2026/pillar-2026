"""
app/core/session_event_store.py

ThreadEventStore — Redis Stream backed event log for the assist pipeline.

STREAM KEY:  thread:{thread_id}:events

One stream per conversation thread. The stream stays open across multiple
turns — it does NOT close when a turn completes. The SSE connection at
GET /events/{thread_id} reads from it for the full assist session.

STREAM ENTRY SCHEMA
===================

Every entry has these fields:
  turn_id    — which user message this event belongs to
  type       — event kind (see below)
  payload    — JSON-encoded event-specific data

EVENT TYPES
===========
  node_start      LangGraph node started     {"node": "mcp_node"}
  node_complete   LangGraph node finished    {"node": "mcp_node"}
  token           LLM streaming token        {"content": "Based on..."}
  elicitation     User input required        {"elicitation_id", "mode", "message", "url", "schema"}
  complete        Turn finished              {"answer": "...", "metadata": {...}}
  error           Turn failed                {"message": "..."}

CURSOR / RECONNECTION
=====================
Every SSE event includes the Redis Stream entry_id.
On reconnect: GET /events/{thread_id}?cursor=<last_entry_id>
XREAD resumes from that position. Zero duplicates. Zero gaps.

The stream stays open between turns. A turn 'complete' event does NOT
close the stream — the next POST /assist will produce more events on
the same stream.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncGenerator

logger = logging.getLogger(__name__)

_STREAM_END   = "_stream_end"   # sentinel: thread permanently closed
_DEFAULT_TTL  = 7200            # 2 hours — covers full conversation
_DEFAULT_BLOCK = 5000           # ms to block in XREAD


class ThreadEventStore:
    """
    Writes and reads events for a conversation thread via Redis Streams.

    Any pod can write. Any pod can read. No affinity needed.

    Write (GraphRunner, any pod):
        await store.append(thread_id, turn_id, event_type, payload)
        await store.mark_turn_complete(thread_id, turn_id, answer)

    Read (GET /events endpoint, any pod):
        async for event in store.read_events(thread_id, cursor="0-0"):
            yield f"id: {event['entry_id']}\\ndata: {json.dumps(event)}\\n\\n"
    """

    def __init__(
        self,
        redis_client:       Any,
        stream_ttl_seconds: int = _DEFAULT_TTL,
        read_block_ms:      int = _DEFAULT_BLOCK,
    ) -> None:
        self._redis    = redis_client
        self._ttl      = stream_ttl_seconds
        self._block_ms = read_block_ms

    # -------------------------------------------------------------------------
    # Write side
    # -------------------------------------------------------------------------

    async def append(
        self,
        thread_id:  str,
        turn_id:    str,
        event_type: str,
        payload:    dict,
    ) -> str:
        """
        Append one event to the thread's Redis Stream.

        Returns the Redis Stream entry ID (e.g. "1234567890123-0").
        """
        key      = self._key(thread_id)
        entry_id = await self._redis.xadd(
            key,
            {
                "turn_id": turn_id,
                "type":    event_type,
                "payload": json.dumps(payload),
            },
        )
        # Refresh TTL on every write so active threads don't expire mid-session
        await self._redis.expire(key, self._ttl)
        logger.debug(
            "XADD: thread=%s turn=%s type=%s id=%s",
            thread_id[:8], turn_id[:8], event_type, entry_id,
        )
        return entry_id

    async def mark_turn_complete(
        self,
        thread_id: str,
        turn_id:   str,
        answer:    str = "",
        metadata:  dict | None = None,
    ) -> None:
        """
        Write a 'complete' event for this turn.
        Does NOT close the stream — more turns can follow.
        """
        await self.append(thread_id, turn_id, "complete", {
            "answer":   answer,
            "metadata": metadata or {},
        })
        logger.info("Turn complete: thread=%s turn=%s", thread_id[:8], turn_id[:8])

    async def mark_turn_error(
        self,
        thread_id: str,
        turn_id:   str,
        message:   str,
    ) -> None:
        """Write an 'error' event for this turn. Stream stays open."""
        await self.append(thread_id, turn_id, "error", {"message": message})

    async def close_thread(self, thread_id: str) -> None:
        """
        Write the sentinel that tells SSE readers to close.
        Call only when the entire conversation is permanently over.
        Normal turn completion does NOT close the thread.
        """
        key = self._key(thread_id)
        await self._redis.xadd(key, {
            "turn_id": "_system",
            "type":    _STREAM_END,
            "payload": "{}",
        })
        logger.info("Thread closed: thread=%s", thread_id[:8])

    # -------------------------------------------------------------------------
    # Read side
    # -------------------------------------------------------------------------

    async def read_events(
        self,
        thread_id: str,
        cursor:    str = "0-0",
    ) -> AsyncGenerator[dict, None]:
        """
        Async generator yielding events from the thread's Redis Stream.

        - Reads from `cursor` forward immediately (history replay).
        - Blocks with XREAD BLOCK when caught up (real-time delivery).
        - Only stops on the _stream_end sentinel or client disconnect
          (handled in the SSE endpoint via request.is_disconnected()).
        - Does NOT stop on 'complete' events — more turns will follow.

        Yields:
            {
                "entry_id": "1234567890123-0",  ← client saves as cursor
                "turn_id":  "uuid",
                "type":     "token",
                "payload":  {"content": "..."},
            }
        """
        key    = self._key(thread_id)
        cursor = cursor

        while True:
            try:
                results = await self._redis.xread(
                    {key: cursor},
                    block=self._block_ms,
                    count=100,
                )
            except Exception as exc:
                logger.exception(
                    "XREAD error: thread=%s cursor=%s", thread_id[:8], cursor
                )
                yield {
                    "entry_id": cursor,
                    "turn_id":  "_system",
                    "type":     "error",
                    "payload":  {"message": f"Stream read error: {exc}"},
                }
                return

            if not results:
                # XREAD timed out — no new events yet. Block again.
                continue

            for entry_id, fields in results[0][1]:
                if isinstance(entry_id, bytes):
                    entry_id = entry_id.decode()
                fields = _decode(fields)

                event_type = fields.get("type", "")
                turn_id    = fields.get("turn_id", "")
                try:
                    payload = json.loads(fields.get("payload", "{}"))
                except json.JSONDecodeError:
                    payload = {}

                cursor = entry_id

                if event_type == _STREAM_END:
                    return

                yield {
                    "entry_id": entry_id,
                    "turn_id":  turn_id,
                    "type":     event_type,
                    "payload":  payload,
                }

    # -------------------------------------------------------------------------
    # Utility
    # -------------------------------------------------------------------------

    async def thread_exists(self, thread_id: str) -> bool:
        return bool(await self._redis.exists(self._key(thread_id)))

    def _key(self, thread_id: str) -> str:
        return f"thread:{thread_id}:events"


def _decode(fields: dict) -> dict:
    return {
        (k.decode() if isinstance(k, bytes) else k):
        (v.decode() if isinstance(v, bytes) else v)
        for k, v in fields.items()
    }
