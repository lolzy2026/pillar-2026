"""
app/api/events.py

GET /api/v1/events/{thread_id}

Single SSE connection for the full assist conversation.

- Opens once when user enters assist mode.
- Stays open across multiple turns (does not close on 'complete' events).
- Any pod can serve it — reads from Redis Stream via XREAD BLOCK.
- Reconnect with ?cursor=<last_entry_id> to resume without missing events.

SSE EVENT FORMAT

  id: 1234567890123-0
  data: {"entry_id": "...", "turn_id": "...", "type": "token", "payload": {"content": "..."}}

  (blank line)

The `id:` field is the standard SSE last-event-id. The browser EventSource
API stores it automatically as event.lastEventId. On reconnect, pass it as
?cursor= to resume from exactly that position.

EVENT TYPES THE CLIENT RECEIVES

  node_start      {"node": "mcp_node"}
  node_complete   {"node": "mcp_node"}
  token           {"content": "Based on..."}
  elicitation     {"elicitation_id", "mode", "message", "url", "schema", "tool_name"}
  complete        {"answer": "...", "metadata": {...}}
  error           {"message": "..."}

USAGE IN THE BROWSER

  const es = new EventSource(`/api/v1/events/${threadId}`);

  es.addEventListener('message', (e) => {
    const event = JSON.parse(e.data);
    const cursor = event.entry_id;  // save for reconnect

    if (event.type === 'token') appendToken(event.turn_id, event.payload.content);
    if (event.type === 'elicitation') showElicitationForm(event.payload);
    if (event.type === 'complete') markTurnDone(event.turn_id, event.payload.answer);
    if (event.type === 'error') markTurnError(event.turn_id, event.payload.message);
  });

  // On reconnect (EventSource does this automatically with Last-Event-ID header,
  // OR pass cursor manually):
  // const es = new EventSource(`/api/v1/events/${threadId}?cursor=${lastCursor}`);

WHEN TO OPEN / CLOSE

  Open:  when user selects the assist expert from the dropdown.
  Close: when user switches away from assist mode (es.close()).

  The connection is idle between turns — XREAD BLOCK uses 0 CPU while waiting.
  Re-opening is cheap (cursor resumes from last position), so close/reopen
  per-message is also fine if the client prefers that pattern.
"""

from __future__ import annotations

import json
import logging

from fastapi import APIRouter, HTTPException, Query, Request, status
from fastapi.responses import StreamingResponse

from app.core.session_event_store import ThreadEventStore

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/events/{thread_id}")
async def get_events(
    thread_id: str,
    request:   Request,
    cursor:    str = Query(
        default="0-0",
        description=(
            "Redis Stream cursor. Pass the last received entry_id to reconnect "
            "without missing events. '0-0' reads from the beginning of the thread."
        ),
    ),
):
    """
    SSE stream for one assist conversation thread.

    Returns events as they are produced by the background graph task.
    Stays open between turns — does not close on 'complete' events.
    Any pod can serve this endpoint (reads from Redis, no affinity needed).
    """
    store: ThreadEventStore = request.app.state.event_store

    # Return 404 if no stream exists yet for this thread.
    # This means POST /assist has not been called yet for this thread_id.
    if not await store.thread_exists(thread_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"No event stream found for thread {thread_id}. "
                "Send a message via POST /api/v1/assist first."
            ),
        )

    async def event_generator():
        try:
            async for event in store.read_events(thread_id, cursor=cursor):
                entry_id = event.get("entry_id", "")
                data     = json.dumps({
                    "entry_id": entry_id,
                    "turn_id":  event["turn_id"],
                    "type":     event["type"],
                    "payload":  event["payload"],
                })
                # Standard SSE:
                #   id: <entry_id>   ← browser stores as lastEventId for reconnect
                #   data: <json>
                #   (blank line)
                yield f"id: {entry_id}\ndata: {data}\n\n"

                if await request.is_disconnected():
                    logger.info("SSE client disconnected: thread=%s", thread_id[:8])
                    return

        except Exception:
            logger.exception("SSE stream error: thread=%s", thread_id[:8])
            error_data = json.dumps({
                "entry_id": "",
                "turn_id":  "_system",
                "type":     "error",
                "payload":  {"message": "Stream error — reconnect to resume"},
            })
            yield f"data: {error_data}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control":     "no-cache",
            "X-Accel-Buffering": "no",       # disable nginx buffering for SSE
            "Connection":        "keep-alive",
        },
    )
