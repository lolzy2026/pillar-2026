"""
app/core/elicitation_bridge.py

ElicitationBridge — distributed-ready Future registry with full race condition handling.

RESOLUTION PATHS
================

Two independent signals can resolve any URL elicitation Future.
The FIRST one to arrive wins. The second is silently ignored (idempotent).

  Path A — MCP completion notification (automatic, server-driven):
    User completes OAuth → MCP server sends notifications/elicitation/complete
    { elicitationId } over the dedicated notification SSE connection.
    NotificationListener receives it → bridge.resolve_from_notification(id).

  Path B — Manual user POST (fallback, per MCP spec requirement):
    User clicks "I've finished" → POST /assist { is_elicitation_response: true }.
    /assist endpoint → bridge.resolve(session_id, elicitation_id, action, content).

The MCP spec explicitly requires clients to provide manual fallback controls
in case the notification never arrives. Both paths are mandatory.

RACE CONDITIONS HANDLED
=======================

RC-1  Notification arrives before register() is called.
      —  Single-worker: parks in _early_notifications (in-process dict).
         register() checks it and returns a pre-resolved Future immediately.
      —  Distributed: parks in Redis with a TTL key
         (key: mcp:elicit:early:{id}, TTL: early_notification_ttl_seconds).
         register() does a non-blocking Redis GET before creating the Future.
         If found, the Future is immediately resolved and the key deleted.

RC-2  Path A and Path B arrive simultaneously.
      future.done() check before set_result(). Second caller returns False.

RC-3  Manual POST after notification already resolved.
      Same as RC-2. /assist returns HTTP 200 (idempotent, not an error).

RC-4  Notification after timeout/cancel.
      _completed_ids set + future.done() check — ignored per spec.

RC-5  Worker B resolves, Worker A holds the Future (distributed).
      Worker B publishes to Redis channel mcp:elicit:{id}.
      Worker A's per-Future subscriber task reads the message and calls
      local resolve(). The Future never crosses process boundaries —
      only the tiny resolution payload does.

RC-6  Multiple sequential elicitations for one session.
      Key is (session_id, elicitation_id). Multiple active Futures supported.

RC-7  Duplicate notifications.
      _completed_ids + future.done() check. No-op.

RC-8  Stale notification from reconnected MCP session.
      Same as RC-7.

DEPLOYMENT MODES
================

  Local (single worker, default):
    bridge = ElicitationBridge()
    No external dependencies.

  Distributed (multi-worker / K8s):
    bridge = ElicitationBridge(redis_url="redis://localhost:6379")
    Requires: pip install redis[asyncio]
    Set via env: REDIS_URL=redis://localhost:6379

  Interface is identical for both modes.
  Switch is a single environment variable.

TIMEOUT POLICY
==============

  url_elicitation_ttl_seconds:      600  (10 min) — waiting for OAuth completion
  form_elicitation_ttl_seconds:     600  (10 min) — waiting for form submit
  early_notification_ttl_seconds:   300  ( 5 min) — parked pre-registration notifs
  Redis early key TTL:              same as early_notification_ttl_seconds
  Redis subscriber timeout:         elicitation TTL + 30s buffer

WHY NOTIFICATION ARRIVES ON A SEPARATE CONNECTION (important design note)
=========================================================================

In Pattern 2 (UrlElicitationRequiredError), the tool call terminates immediately.
The MCP SSE connection that delivered the tool call is CLOSED by the time the
user completes the OAuth flow. There is no live per-request connection to receive
notifications on.

The notifications/elicitation/complete notification therefore arrives on a
SEPARATE persistent SSE connection that must be maintained independently of
individual tool calls. This is the NotificationListener (see notification_listener.py).

In Pattern 1 (ctx.elicit_url), the tool is suspended and the SSE connection IS
alive. Notifications arriving there are handled by _on_notification in
MCPSessionManager. But for Pattern 2, the NotificationListener is the only
delivery path.
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any

from mcp.types import ElicitResult

logger = logging.getLogger(__name__)

# Redis key prefixes
_REDIS_CHANNEL_PREFIX = "mcp:elicit:"           # pub/sub resolution channel
_REDIS_EARLY_PREFIX   = "mcp:elicit:early:"     # RC-1 early notification keys


class ElicitationKind(str, Enum):
    FORM = "form"
    URL  = "url"


@dataclass
class PendingElicitation:
    future:           asyncio.Future
    session_id:       str
    elicitation_id:   str
    kind:             ElicitationKind
    created_at:       datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    server_name:      str = ""
    tool_name:        str = ""
    # Redis subscriber task (distributed mode only, one per pending Future)
    _subscriber_task: asyncio.Task | None = field(default=None, repr=False, compare=False)


@dataclass
class EarlyNotification:
    """Notification that arrived before register() was called (RC-1, local mode)."""
    elicitation_id: str
    arrived_at:     datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class ElicitationTimeoutError(Exception):
    """Raised when an elicitation exceeds its TTL."""


class ElicitationCancelledError(Exception):
    """Raised when an elicitation is cancelled (shutdown / client disconnect)."""


class ElicitationBridge:
    """
    Manages asyncio.Future instances for all pending elicitations.

    Supports in-process (single worker) and distributed (Redis) deployments.
    Interface is identical for both modes — select via redis_url constructor arg.
    """

    def __init__(
        self,
        redis_url:                      str | None = None,
        url_elicitation_ttl_seconds:    int = 600,
        form_elicitation_ttl_seconds:   int = 600,
        early_notification_ttl_seconds: int = 300,
        cleanup_interval_seconds:       int = 60,
    ) -> None:
        self._redis_url        = redis_url
        self._url_ttl          = timedelta(seconds=url_elicitation_ttl_seconds)
        self._form_ttl         = timedelta(seconds=form_elicitation_ttl_seconds)
        self._early_ttl        = timedelta(seconds=early_notification_ttl_seconds)
        self._early_ttl_secs   = early_notification_ttl_seconds
        self._cleanup_interval = cleanup_interval_seconds
        self._is_distributed   = redis_url is not None

        # (session_id, elicitation_id) → PendingElicitation
        self._pending: dict[tuple[str, str], PendingElicitation] = {}

        # RC-1 store for single-worker mode:
        # elicitation_id → EarlyNotification
        # In distributed mode this is unused; Redis keys serve the same purpose.
        self._early_notifications: dict[str, EarlyNotification] = {}

        # Recently completed IDs (for RC-4/7/8 duplicate suppression).
        # Bounded to 1000 entries by cleanup.
        self._completed_ids: set[str] = set()

        self._cleanup_task: asyncio.Task | None = None
        self._redis_client: Any | None = None      # redis.asyncio.Redis

    # =========================================================================
    # Lifecycle
    # =========================================================================

    async def start(self) -> None:
        """Start background cleanup and connect to Redis if configured."""
        if self._is_distributed:
            await self._connect_redis()

        self._cleanup_task = asyncio.create_task(
            self._cleanup_loop(), name="elicitation-bridge-cleanup"
        )
        logger.info(
            "ElicitationBridge started: mode=%s url_ttl=%ds form_ttl=%ds early_ttl=%ds",
            "distributed" if self._is_distributed else "local",
            self._url_ttl.seconds,
            self._form_ttl.seconds,
            self._early_ttl.seconds,
        )

    async def stop(self) -> None:
        """Cancel all pending Futures and release resources."""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass

        for pending in list(self._pending.values()):
            self._cancel_pending(pending, "server shutdown")
        self._pending.clear()
        self._early_notifications.clear()
        self._completed_ids.clear()

        if self._redis_client:
            try:
                await self._redis_client.aclose()
            except Exception:
                pass

        logger.info("ElicitationBridge stopped")

    # =========================================================================
    # Registration
    # =========================================================================

    async def register(
        self,
        session_id:     str,
        elicitation_id: str,
        kind:           ElicitationKind = ElicitationKind.URL,
        server_name:    str = "",
        tool_name:      str = "",
    ) -> asyncio.Future:
        """
        Register a new pending elicitation and return a Future to await.

        Now async to support RC-1 Redis check in distributed mode.

        RC-1 (both modes):
          If a completion notification arrived before this call, the returned
          Future is already resolved — the caller's await returns instantly.
          - Local:       checks _early_notifications dict
          - Distributed: checks Redis early-notification key

        Args:
            session_id:     User session identifier.
            elicitation_id: Unique ID from MCP server (-32042 payload or
                            elicitation/create params).
            kind:           URL or FORM — governs which TTL applies.
            server_name:    MCP server name (for logging).
            tool_name:      Tool that triggered elicitation (for logging).

        Returns:
            asyncio.Future — may already be done if RC-1 applies.
        """
        key = (session_id, elicitation_id)

        # Duplicate registration guard
        if key in self._pending:
            existing = self._pending[key]
            if not existing.future.done():
                logger.warning(
                    "Duplicate register(): session=%s id=%s — returning existing Future",
                    session_id, elicitation_id,
                )
                return existing.future
            self._pending.pop(key, None)

        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()

        pending = PendingElicitation(
            future=future,
            session_id=session_id,
            elicitation_id=elicitation_id,
            kind=kind,
            server_name=server_name,
            tool_name=tool_name,
        )
        self._pending[key] = pending

        # ── RC-1: check for early notification ───────────────────────────────
        early_arrived = await self._check_early_notification(elicitation_id)
        if early_arrived:
            age_msg = f"(local, arrived {datetime.now(timezone.utc) - early_arrived.arrived_at} ago)" \
                      if early_arrived is not True else "(distributed Redis key found)"
            logger.info(
                "RC-1: early notification resolved Future immediately: "
                "session=%s id=%s %s",
                session_id, elicitation_id, age_msg,
            )
            future.set_result(ElicitResult(action="accept", content={}))
            self._completed_ids.add(elicitation_id)
            self._pending.pop(key, None)
            return future

        # ── Distributed: start per-Future Redis subscriber ───────────────────
        if self._is_distributed:
            pending._subscriber_task = asyncio.create_task(
                self._redis_subscribe_and_resolve(key),
                name=f"elicit-sub-{elicitation_id[:8]}",
            )

        logger.debug(
            "Registered: session=%s id=%s kind=%s tool=%s",
            session_id, elicitation_id, kind.value, tool_name,
        )
        return future

    # =========================================================================
    # Resolution — Path B (manual POST)
    # =========================================================================

    def resolve(
        self,
        session_id:     str,
        elicitation_id: str,
        action:         str,
        content:        dict[str, Any] | None = None,
    ) -> bool:
        """
        Resolve a pending elicitation with an explicit action.

        Called by:
          - POST /assist endpoint (Path B, user confirmation)
          - _redis_subscribe_and_resolve() (Path A via Redis, distributed mode)

        Returns True if resolved, False if already done / not found (idempotent).
        """
        key = (session_id, elicitation_id)
        pending = self._pending.get(key)

        if not pending:
            logger.warning(
                "resolve() for unknown elicitation: session=%s id=%s "
                "(already resolved, timed out, or wrong session_id)",
                session_id, elicitation_id,
            )
            return False

        if pending.future.done():
            # RC-2/RC-3: race — other path resolved first. Idempotent.
            logger.debug(
                "resolve() race — Future already done: session=%s id=%s",
                session_id, elicitation_id,
            )
            self._cleanup_pending(pending, key)
            return False

        pending.future.set_result(ElicitResult(action=action, content=content or {}))
        self._completed_ids.add(elicitation_id)
        self._cleanup_pending(pending, key)

        logger.info(
            "Resolved (Path B / manual): session=%s id=%s action=%s",
            session_id, elicitation_id, action,
        )
        return True

    # =========================================================================
    # Resolution — Path A (MCP notification)
    # =========================================================================

    async def resolve_from_notification(
        self,
        elicitation_id: str,
    ) -> bool:
        """
        Resolve an elicitation from a notifications/elicitation/complete message.

        Called by:
          - NotificationListener (Pattern 2 — dedicated persistent SSE connection)
          - MCPSessionManager._on_notification (Pattern 1 — tool-call SSE connection)

        Per MCP spec: clients MUST ignore notifications for unknown or
        already-completed IDs. This is enforced here.

        In distributed mode: publishes to Redis AND resolves locally.
        Both are needed — the Future may be on this worker or another.

        Returns True if a local Future was resolved.
        """
        # RC-4/RC-7/RC-8: already completed — ignore per spec
        if elicitation_id in self._completed_ids:
            logger.debug(
                "Notification for already-completed id=%s ignored (RC-4/7/8)",
                elicitation_id,
            )
            return False

        # Distributed: publish to Redis FIRST so all workers get it concurrently.
        # We still try local resolution below — this worker might hold the Future.
        if self._is_distributed:
            await self._redis_publish(elicitation_id, action="accept", content={})

        # Try to resolve a local Future
        resolved = self._resolve_by_elicitation_id(elicitation_id)

        if resolved:
            logger.info("Resolved (Path A / notification): id=%s", elicitation_id)
            return True

        # Future not found locally.
        # RC-1: It may not have been registered yet (notification beat register()).
        # Park it so register() can pick it up.
        #   - Local mode:       park in _early_notifications dict
        #   - Distributed mode: park in Redis with TTL (cross-worker safe)
        #     (the Redis publish above already handles the cross-worker resolution
        #      case; the early Redis key handles the RC-1 case for the worker
        #      that WILL call register())

        already_done = self._is_elicitation_done(elicitation_id)
        if not already_done:
            await self._park_early_notification(elicitation_id)
            logger.info(
                "Notification before register() (RC-1): id=%s — parked (%s)",
                elicitation_id,
                "Redis" if self._is_distributed else "local",
            )
        else:
            logger.debug(
                "Notification for done elicitation: id=%s (RC-4/7/8)", elicitation_id
            )

        return False

    # =========================================================================
    # Queries
    # =========================================================================

    def has_pending(self, session_id: str) -> bool:
        return any(k[0] == session_id for k in self._pending)

    def get_pending_ids(self, session_id: str) -> list[str]:
        return [eid for (sid, eid) in self._pending if sid == session_id]

    def pending_count(self) -> int:
        return len(self._pending)

    def early_notification_count(self) -> int:
        return len(self._early_notifications)

    # =========================================================================
    # Private: local resolution helpers
    # =========================================================================

    def _resolve_by_elicitation_id(
        self,
        elicitation_id: str,
        action: str = "accept",
        content: dict | None = None,
    ) -> bool:
        """Find and resolve a pending entry by elicitation_id (session unknown)."""
        for key, pending in list(self._pending.items()):
            if pending.elicitation_id == elicitation_id:
                if pending.future.done():
                    self._cleanup_pending(pending, key)
                    return False
                pending.future.set_result(
                    ElicitResult(action=action, content=content or {})
                )
                self._completed_ids.add(elicitation_id)
                self._cleanup_pending(pending, key)
                return True
        return False

    def _is_elicitation_done(self, elicitation_id: str) -> bool:
        """Return True if an elicitation with this ID has a done Future."""
        for key, pending in self._pending.items():
            if pending.elicitation_id == elicitation_id:
                return pending.future.done()
        return False

    def _cleanup_pending(
        self,
        pending: PendingElicitation,
        key: tuple[str, str],
    ) -> None:
        """Remove from dict and cancel distributed subscriber task."""
        self._pending.pop(key, None)
        if pending._subscriber_task and not pending._subscriber_task.done():
            pending._subscriber_task.cancel()

    def _cancel_pending(self, pending: PendingElicitation, reason: str) -> None:
        if not pending.future.done():
            pending.future.set_exception(
                ElicitationCancelledError(
                    f"Elicitation {pending.elicitation_id} cancelled: {reason}"
                )
            )
        if pending._subscriber_task and not pending._subscriber_task.done():
            pending._subscriber_task.cancel()

    # =========================================================================
    # Private: RC-1 early notification store
    # =========================================================================

    async def _park_early_notification(self, elicitation_id: str) -> None:
        """Park a notification that arrived before register()."""
        if self._is_distributed:
            # Store in Redis with TTL so any worker's register() can find it
            key = f"{_REDIS_EARLY_PREFIX}{elicitation_id}"
            try:
                await self._redis_client.set(
                    key, "1", ex=self._early_ttl_secs
                )
            except Exception:
                logger.exception(
                    "Failed to park early notification in Redis: id=%s", elicitation_id
                )
        else:
            self._early_notifications[elicitation_id] = EarlyNotification(
                elicitation_id=elicitation_id
            )

    async def _check_early_notification(
        self, elicitation_id: str
    ) -> EarlyNotification | bool | None:
        """
        Check if an early notification was parked for this elicitation_id.

        Returns:
          - EarlyNotification instance if found in local dict (local mode)
          - True if found in Redis (distributed mode — no timestamp available)
          - None if not found
        """
        if self._is_distributed:
            key = f"{_REDIS_EARLY_PREFIX}{elicitation_id}"
            try:
                found = await self._redis_client.getdel(key)
                return True if found else None
            except Exception:
                logger.exception(
                    "Failed to check early notification in Redis: id=%s", elicitation_id
                )
                return None
        else:
            early = self._early_notifications.pop(elicitation_id, None)
            return early  # EarlyNotification or None

    # =========================================================================
    # Private: TTL cleanup
    # =========================================================================

    async def _cleanup_loop(self) -> None:
        while True:
            try:
                await asyncio.sleep(self._cleanup_interval)
                self._cleanup_expired()
            except asyncio.CancelledError:
                break
            except Exception:
                logger.exception("Error in bridge cleanup loop")

    def _cleanup_expired(self) -> None:
        now = datetime.now(timezone.utc)
        expired_keys: list[tuple[str, str]] = []

        for key, pending in list(self._pending.items()):
            ttl = self._url_ttl if pending.kind == ElicitationKind.URL else self._form_ttl
            if (now - pending.created_at) > ttl:
                expired_keys.append(key)

        for key in expired_keys:
            pending = self._pending.pop(key, None)
            if not pending:
                continue
            if not pending.future.done():
                pending.future.set_exception(
                    ElicitationTimeoutError(
                        f"Elicitation {pending.elicitation_id} timed out "
                        f"({pending.kind.value}) for session {pending.session_id}"
                    )
                )
            if pending._subscriber_task and not pending._subscriber_task.done():
                pending._subscriber_task.cancel()
            logger.warning(
                "Timed out: session=%s id=%s kind=%s",
                pending.session_id, pending.elicitation_id, pending.kind.value,
            )

        # Expire local early notifications (Redis entries have their own TTL)
        expired_early = [
            eid for eid, en in self._early_notifications.items()
            if (now - en.arrived_at) > self._early_ttl
        ]
        for eid in expired_early:
            self._early_notifications.pop(eid, None)

        # Bound the completed_ids set at 1000 entries
        if len(self._completed_ids) > 1000:
            overage = len(self._completed_ids) - 1000
            for eid in list(self._completed_ids)[:overage]:
                self._completed_ids.discard(eid)

        if expired_keys or expired_early:
            logger.info(
                "Cleanup: expired %d elicitations, %d local early notifications",
                len(expired_keys), len(expired_early),
            )

    # =========================================================================
    # Private: Redis distributed backend
    # =========================================================================

    async def _connect_redis(self) -> None:
        try:
            import redis.asyncio as aioredis  # type: ignore[import]
        except ImportError:
            raise RuntimeError(
                "Distributed bridge requires 'redis[asyncio]'. "
                "Install with: pip install redis[asyncio]"
            ) from None

        self._redis_client = aioredis.from_url(
            self._redis_url,
            decode_responses=True,
            socket_keepalive=True,
            socket_connect_timeout=5,
            retry_on_timeout=True,
            health_check_interval=30,
        )
        await self._redis_client.ping()
        logger.info("ElicitationBridge connected to Redis: %s", self._redis_url)

    async def _redis_publish(
        self,
        elicitation_id: str,
        action:         str,
        content:        dict,
    ) -> None:
        if not self._redis_client:
            logger.error("Redis not connected — cannot publish resolution")
            return
        channel = f"{_REDIS_CHANNEL_PREFIX}{elicitation_id}"
        payload = json.dumps({"action": action, "content": content})
        try:
            await self._redis_client.publish(channel, payload)
            logger.debug("Published to Redis channel: %s", channel)
        except Exception:
            logger.exception("Failed to publish to Redis channel %s", channel)

    async def _redis_subscribe_and_resolve(
        self,
        key: tuple[str, str],
    ) -> None:
        """
        Per-Future Redis subscriber task (distributed mode only).

        One task per pending Future. Subscribes to mcp:elicit:{elicitation_id}.
        When a resolution message arrives from any worker, calls local resolve()
        to unblock this worker's Future.

        RC-5: This is the mechanism by which Worker A's Future is resolved when
        Worker B (or a NotificationListener on any pod) publishes the resolution.

        Lifecycle:
          - Created by register() in distributed mode
          - Cancelled by _cleanup_pending() when the Future resolves by any path
          - Self-terminates on timeout (TTL + 30s buffer)
        """
        session_id, elicitation_id = key
        channel = f"{_REDIS_CHANNEL_PREFIX}{elicitation_id}"

        pending = self._pending.get(key)
        if not pending:
            return

        ttl = self._url_ttl if pending.kind == ElicitationKind.URL else self._form_ttl
        subscriber_timeout = ttl.total_seconds() + 30.0

        pubsub = None
        try:
            pubsub = self._redis_client.pubsub()
            await pubsub.subscribe(channel)
            logger.debug(
                "Redis subscriber started: session=%s id=%s channel=%s",
                session_id, elicitation_id, channel,
            )

            async def _read_one_message() -> dict | None:
                async for msg in pubsub.listen():
                    if msg["type"] == "message":
                        return json.loads(msg["data"])
                return None

            try:
                data = await asyncio.wait_for(
                    _read_one_message(), timeout=subscriber_timeout
                )
            except asyncio.TimeoutError:
                # TTL cleanup will set exception on the Future
                logger.debug(
                    "Redis subscriber timeout: session=%s id=%s "
                    "(TTL cleanup will handle the Future)",
                    session_id, elicitation_id,
                )
                return

            if data:
                action  = data.get("action", "cancel")
                content = data.get("content", {})
                resolved = self.resolve(
                    session_id=session_id,
                    elicitation_id=elicitation_id,
                    action=action,
                    content=content,
                )
                if resolved:
                    logger.info(
                        "Redis subscriber resolved Future (RC-5): "
                        "session=%s id=%s action=%s",
                        session_id, elicitation_id, action,
                    )

        except asyncio.CancelledError:
            pass  # Normal: cancelled by _cleanup_pending when resolved by other path
        except Exception:
            logger.exception(
                "Redis subscriber error: session=%s id=%s",
                session_id, elicitation_id,
            )
        finally:
            if pubsub:
                try:
                    await pubsub.unsubscribe(channel)
                    await pubsub.aclose()
                except Exception:
                    pass
