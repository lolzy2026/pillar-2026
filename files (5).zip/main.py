"""
app/main.py

FastAPI application — MCP Assist Service.

STARTUP ORDER
=============
1. Redis              shared by ElicitationBridge + ThreadEventStore
2. ElicitationBridge  distributed Future registry (Redis pub/sub + early keys)
3. MCPSessionManager  per-request MCP sessions + tool cache
4. NotificationListener  persistent MCP SSE for elicitation/complete notifications
5. PostgreSQL         LangGraph checkpointer
6. LangGraph          compiled graph (tools injected per-request)
7. ThreadEventStore   Redis Stream event log (thread-scoped)
8. GraphRunner        wires everything together

API SURFACE
===========
  POST /api/v1/assist                 start turn or submit elicitation response
  GET  /api/v1/events/{thread_id}     SSE stream for the conversation
  GET  /health                        liveness + stats

ENVIRONMENT VARIABLES
=====================
  Required:
    REDIS_URL         e.g. redis://localhost:6379
    MCP_SERVER_URL    e.g. http://localhost:8001
    POSTGRES_DSN      e.g. postgresql://user:pass@localhost/db

  Optional:
    MCP_SERVER_NAME               default: "default"
    MCP_TRANSPORT                 default: "streamable_http"
    TOOL_CACHE_TTL_SECONDS        default: 300
    URL_ELICITATION_TTL_SECONDS   default: 600
    FORM_ELICITATION_TTL_SECONDS  default: 600
    EARLY_NOTIFICATION_TTL_SECONDS default: 300
    THREAD_STREAM_TTL_SECONDS     default: 7200
    CORS_ORIGINS                  default: "*"
"""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

import asyncpg
import redis.asyncio as aioredis
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

from app.api.assist import router as assist_router
from app.api.events import router as events_router
from app.core.elicitation_bridge import ElicitationBridge
from app.core.graph_runner import GraphRunner
from app.core.mcp_session_manager import MCPSessionManager
from app.core.notification_listener import NotificationListener
from app.core.session_event_store import ThreadEventStore
from app.graph.builder import build_graph

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("=== Startup ===")

    # 1. Redis
    redis_url    = os.environ["REDIS_URL"]
    redis_client = aioredis.from_url(
        redis_url,
        decode_responses=True,
        socket_keepalive=True,
        socket_connect_timeout=5,
        retry_on_timeout=True,
        health_check_interval=30,
    )
    await redis_client.ping()
    logger.info("Redis connected: %s", redis_url)
    app.state.redis_client = redis_client

    # 2. ElicitationBridge
    bridge = ElicitationBridge(
        redis_url=redis_url,
        url_elicitation_ttl_seconds=int(
            os.getenv("URL_ELICITATION_TTL_SECONDS", "600")
        ),
        form_elicitation_ttl_seconds=int(
            os.getenv("FORM_ELICITATION_TTL_SECONDS", "600")
        ),
        early_notification_ttl_seconds=int(
            os.getenv("EARLY_NOTIFICATION_TTL_SECONDS", "300")
        ),
    )
    await bridge.start()
    app.state.elicitation_bridge = bridge

    # 3. MCPSessionManager
    mcp_manager = MCPSessionManager(
        server_url=os.environ["MCP_SERVER_URL"],
        bridge=bridge,
        server_name=os.getenv("MCP_SERVER_NAME", "default"),
        transport=os.getenv("MCP_TRANSPORT", "streamable_http"),
        tool_cache_ttl_seconds=int(os.getenv("TOOL_CACHE_TTL_SECONDS", "300")),
    )
    await mcp_manager.start()
    app.state.mcp_manager = mcp_manager

    # 4. NotificationListener
    notification_listener = NotificationListener(
        server_url=os.environ["MCP_SERVER_URL"],
        bridge=bridge,
        server_name=os.getenv("MCP_SERVER_NAME", "default"),
        transport=os.getenv("MCP_TRANSPORT", "streamable_http"),
    )
    await notification_listener.start()
    app.state.notification_listener = notification_listener

    # 5. PostgreSQL
    pool = await asyncpg.create_pool(
        os.environ["POSTGRES_DSN"],
        min_size=5,
        max_size=20,
        command_timeout=30,
    )
    checkpointer = AsyncPostgresSaver(pool)
    await checkpointer.setup()
    app.state.pg_pool = pool

    # 6. LangGraph
    compiled_graph = build_graph(checkpointer=checkpointer)
    app.state.compiled_graph = compiled_graph

    # 7. ThreadEventStore
    event_store = ThreadEventStore(
        redis_client=redis_client,
        stream_ttl_seconds=int(os.getenv("THREAD_STREAM_TTL_SECONDS", "7200")),
    )
    app.state.event_store = event_store

    # 8. GraphRunner
    app.state.graph_runner = GraphRunner(
        compiled_graph=compiled_graph,
        bridge=bridge,
        mcp_manager=mcp_manager,
        event_store=event_store,
        notification_listener=notification_listener,
    )

    logger.info("=== Ready ===")
    yield

    # Shutdown (reverse order)
    logger.info("=== Shutdown ===")
    await app.state.graph_runner.stop()
    await bridge.stop()
    await mcp_manager.stop()
    await notification_listener.stop()
    await pool.close()
    await redis_client.aclose()
    logger.info("=== Done ===")


def create_app() -> FastAPI:
    app = FastAPI(
        title="MCP Assist Service",
        version="2.0.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
        allow_credentials=True,
        allow_methods=["POST", "GET", "OPTIONS"],
        allow_headers=["*"],
    )

    app.include_router(assist_router, prefix="/api/v1", tags=["assist"])
    app.include_router(events_router, prefix="/api/v1", tags=["events"])

    @app.get("/health", tags=["ops"])
    async def health():
        bridge: ElicitationBridge   = app.state.elicitation_bridge
        nl:     NotificationListener = app.state.notification_listener
        return {
            "status":                 "ok",
            "pending_elicitations":   bridge.pending_count(),
            "early_notifications":    bridge.early_notification_count(),
            "notification_listeners": nl.listener_count(),
        }

    return app


app = create_app()
