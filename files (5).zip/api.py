"""app/models/api.py"""
from __future__ import annotations
from typing import Any
from pydantic import BaseModel, Field


class AssistRequest(BaseModel):
    thread_id: str = Field(..., description="Stable conversation thread ID")
    turn_id:   str = Field(..., description="UUID for this message, client-generated")
    message:   str = Field(default="")

    # Elicitation response fields
    is_elicitation_response: bool                  = False
    elicitation_id:          str | None            = None
    elicitation_action:      str                   = "accept"
    elicitation_content:     dict[str, Any] | None = None
