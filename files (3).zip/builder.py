"""
app/graph/builder.py

Builds and compiles the LangGraph assist graph.

Compiled ONCE at application startup (FastAPI lifespan) and reused
across all requests. Thread safety per invocation is guaranteed by
the LangGraph checkpointer — each call uses its own thread_id (session_id).

Graph topology (elicitation_node removed — elicitation is transparent in mcp_node):

    START
      │
      ▼
    guardrail_node
      │
      ├─(unsafe)──────────────────────────┐
      ▼                                   │
    query_rephrase_node                   │
      │                                   │
      ▼                                   │
    mcp_node                              │
      │  └─ elicitation fires here        │
      │     transparently inside          │
      │     tool.ainvoke()                │
      ▼                                   ▼
    answer_generation_node ◄──────────────┘
      │
      ▼
     END

Per-request objects (mcp_client, mcp_tools) are injected via config
["configurable"] by GraphRunner — NOT stored in state — so they are
never serialised into the PostgreSQL checkpoint.
"""

from __future__ import annotations

import logging
from typing import Any

from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.graph import END, START, StateGraph

from app.models.state import GraphState
from app.nodes.graph_nodes import (
    answer_generation_node,
    guardrail_node,
    mcp_node,
    query_rephrase_node,
    should_continue_after_guardrail,
)

logger = logging.getLogger(__name__)


def build_graph(checkpointer: AsyncPostgresSaver) -> Any:
    """
    Build and compile the LangGraph assist graph.

    Note: mcp_tools are no longer passed here. They are injected per-request
    via config["configurable"]["mcp_tools"] by GraphRunner. This means the
    graph doesn't need to be recompiled if tools change — just update the
    MCPSessionManager's cache.

    Args:
        checkpointer: PostgreSQL-backed async checkpointer.

    Returns:
        Compiled LangGraph (CompiledStateGraph).
    """
    builder = StateGraph(GraphState)

    # ── Register nodes ────────────────────────────────────────────────────────
    builder.add_node("guardrail_node", guardrail_node)
    builder.add_node("query_rephrase_node", query_rephrase_node)
    builder.add_node("mcp_node", mcp_node)
    builder.add_node("answer_generation_node", answer_generation_node)

    # ── Edges ─────────────────────────────────────────────────────────────────
    builder.add_edge(START, "guardrail_node")

    builder.add_conditional_edges(
        "guardrail_node",
        should_continue_after_guardrail,
        {
            "query_rephrase_node": "query_rephrase_node",
            "answer_generation_node": "answer_generation_node",
        },
    )

    builder.add_edge("query_rephrase_node", "mcp_node")
    builder.add_edge("mcp_node", "answer_generation_node")
    builder.add_edge("answer_generation_node", END)

    # ── Compile ───────────────────────────────────────────────────────────────
    compiled = builder.compile(checkpointer=checkpointer)
    logger.info("LangGraph assist graph compiled: 4 nodes, elicitation transparent in mcp_node")
    return compiled
