"""
app/core/mcp_session_manager.py

MCPSessionManager — per-request MCP sessions with token-keyed tool cache.

Design:
- NO app-level long-lived MCP connection.
- Each graph execution opens its own MCP ClientSession using the user's
  Bearer token. This guarantees:
    1. Namespace correctness — the MCP server sees the real user token
       and enforces the right tool set for that user's role.
    2. Elicitation safety — on_elicitation fires on the exact same
       authorized session that is executing the tool. No cross-user leakage.

- Tools are cached by hash(bearer_token) with a configurable TTL (default
  5 minutes). Cache hit = zero MCP round-trip for tool discovery.
  Cache miss = one get_tools() call, result cached for next request.

- The on_elicitation callback is wired at the client level (not session
  level), so it applies to every session opened by this manager.

ContextVar usage:
- current_session_id: carries the session_id into on_elicitation, which
  has a fixed MCP SDK signature and cannot accept extra parameters.
- elicitation_event_emitter: carries the SSE emit callable so
  on_elicitation can push an event to the currently active stream.

Both contextvars are set by GraphRunner before graph invocation and reset
in a finally block. Each asyncio task (one per request) gets its own copy —
no cross-request contamination possible.
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import uuid
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import MultiServerMCPClient
from mcp.types import ElicitResult

from app.core.elicitation_bridge import (
    ElicitationBridge,
    ElicitationCancelledError,
    ElicitationTimeoutError,
)
from app.models.state import ElicitationMode, ElicitationRequest

logger = logging.getLogger(__name__)

# ── ContextVars ───────────────────────────────────────────────────────────────
# Module-level singleton objects. Each async TASK holds its own VALUE.
#
# Why not just pass session_id as a parameter?
# The MCP SDK's on_elicitation callback signature is fixed by the protocol:
#   async def handler(context, params, callback_context) -> ElicitResult
# We cannot add parameters. ContextVar is the standard Python pattern for
# injecting request-scoped values into deeply nested callbacks.
#
# Safety: asyncio copies the current Context into every new Task. Setting a
# contextvar value in Task A does NOT affect Task B. It is impossible for
# User A's session_id to appear in User B's on_elicitation call.
#
# Usage in GraphRunner (before graph invocation):
#   sid_token = current_session_id.set(session_id)
#   emit_token = elicitation_event_emitter.set(emit_fn)
#   try:
#       async for event in graph.astream_events(...): ...
#   finally:
#       current_session_id.reset(sid_token)      # always clean up
#       elicitation_event_emitter.reset(emit_token)

current_session_id: ContextVar[str] = ContextVar("current_session_id", default="")
elicitation_event_emitter: ContextVar[Any] = ContextVar(
    "elicitation_event_emitter", default=None
)


@dataclass
class _CachedToolEntry:
    """A cached tool list with its expiry timestamp."""

    tools: list[BaseTool]
    expires_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    def is_expired(self) -> bool:
        return datetime.now(timezone.utc) >= self.expires_at


class MCPSessionManager:
    """
    Manages per-request MCP sessions and a token-keyed tool cache.

    Lifecycle (FastAPI lifespan):
        await manager.start()   # startup
        await manager.stop()    # shutdown

    Per request (GraphRunner / mcp_node):
        tools = await manager.get_tools(bearer_token)
        async with manager.build_client(bearer_token) as client:
            async with client.session(server_name) as session:
                # execute tools — elicitation is transparent here
    """

    def __init__(
        self,
        server_url: str,
        bridge: ElicitationBridge,
        server_name: str = "default",
        transport: str = "streamable_http",
        tool_cache_ttl_seconds: int = 300,
    ) -> None:
        self._server_url = server_url
        self._server_name = server_name
        self._transport = transport
        self._bridge = bridge
        self._ttl = timedelta(seconds=tool_cache_ttl_seconds)

        # Cache: sha256(bearer_token) → _CachedToolEntry
        # We hash the token so the raw secret never sits in memory longer
        # than needed and never appears in logs.
        self._tool_cache: dict[str, _CachedToolEntry] = {}
        self._cache_lock = asyncio.Lock()
        self._cleanup_task: asyncio.Task | None = None

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start background cache cleanup task. Call from FastAPI lifespan."""
        self._cleanup_task = asyncio.create_task(
            self._cache_cleanup_loop(), name="tool-cache-cleanup"
        )
        logger.info(
            "MCPSessionManager started: server=%s transport=%s cache_ttl=%s",
            self._server_url,
            self._transport,
            self._ttl,
        )

    async def stop(self) -> None:
        """Stop background cleanup and clear cache. Call from FastAPI lifespan."""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        async with self._cache_lock:
            self._tool_cache.clear()
        logger.info("MCPSessionManager stopped")

    # ── Public API ────────────────────────────────────────────────────────────

    async def get_tools(self, bearer_token: str) -> list[BaseTool]:
        """
        Return the tool list for this bearer token, using cache when valid.

        The MCP server enforces namespace based on the token — we forward it
        transparently and cache whatever the server returns. Two users with
        different tokens (different roles) get independently cached tool lists.

        Cache hit  → returns immediately, zero network call.
        Cache miss → opens a short-lived session, fetches tools, caches result.

        Args:
            bearer_token: Raw value from Authorization: Bearer <token> header.

        Returns:
            List of LangChain BaseTool instances allowed for this token's namespace.
        """
        cache_key = _hash_token(bearer_token)

        # Check cache under lock
        async with self._cache_lock:
            entry = self._tool_cache.get(cache_key)
            if entry and not entry.is_expired():
                logger.debug(
                    "Tool cache HIT: key_prefix=%s tools=%d",
                    cache_key[:8], len(entry.tools),
                )
                return entry.tools

        # Cache miss: fetch outside lock so other requests aren't blocked
        # during the network call. Double-check pattern prevents duplicate
        # fetches when two requests for the same token miss simultaneously.
        logger.info("Tool cache MISS: key_prefix=%s — fetching from MCP", cache_key[:8])
        tools = await self._fetch_tools(bearer_token)

        async with self._cache_lock:
            # Double-check: another coroutine may have populated while we fetched
            existing = self._tool_cache.get(cache_key)
            if not existing or existing.is_expired():
                self._tool_cache[cache_key] = _CachedToolEntry(
                    tools=tools,
                    expires_at=datetime.now(timezone.utc) + self._ttl,
                )
                logger.info(
                    "Tool cache SET: key_prefix=%s tools=%d ttl=%s",
                    cache_key[:8], len(tools), self._ttl,
                )

        return tools

    async def invalidate_cache(self, bearer_token: str) -> bool:
        """
        Force-expire the tool cache for a specific token.

        Call this if you know the MCP server's tool list has changed for this
        user (e.g. role change, admin action). The next get_tools() call will
        fetch fresh tools.

        Returns True if an entry was found and removed, False if not cached.
        """
        cache_key = _hash_token(bearer_token)
        async with self._cache_lock:
            removed = self._tool_cache.pop(cache_key, None)
        if removed:
            logger.info("Tool cache invalidated: key_prefix=%s", cache_key[:8])
        return removed is not None

    def build_client(self, bearer_token: str) -> MultiServerMCPClient:
        """
        Build a MultiServerMCPClient for this request's bearer token.

        The client is intended to be used as an async context manager
        within mcp_node for the duration of a single tool execution:

            async with mcp_manager.build_client(token) as client:
                tools = await client.get_tools()
                # OR use cached tools passed in from get_tools()
                result = await tools[0].ainvoke(args)
                # on_elicitation fires here if tool calls ctx.elicit()

        The on_elicitation callback is wired in here. It reads session_id
        from the current_session_id contextvar (set by GraphRunner).

        NOTE: Do NOT share one client across concurrent tool invocations
        from different sessions — each session must have its own client
        instance to keep auth contexts isolated.
        """
        return MultiServerMCPClient(
            {
                self._server_name: {
                    "url": self._server_url,
                    "transport": self._transport,
                    "headers": {
                        "Authorization": f"Bearer {bearer_token}",
                    },
                }
            },
            callbacks={"on_elicitation": self._on_elicitation},
        )

    # ── Private: tool fetching ────────────────────────────────────────────────

    async def _fetch_tools(self, bearer_token: str) -> list[BaseTool]:
        """Open a short-lived MCP session solely to discover tools, then close."""
        client = self.build_client(bearer_token)
        try:
            async with client:
                tools = await client.get_tools()
                logger.info(
                    "Fetched %d tools from MCP server: %s",
                    len(tools), [t.name for t in tools],
                )
                return tools
        except Exception:
            logger.exception("Failed to fetch tools from MCP server %s", self._server_url)
            raise

    # ── Private: elicitation callback ─────────────────────────────────────────

    async def _on_elicitation(
        self,
        context: Any,           # mcp.shared.context.RequestContext
        params: Any,            # mcp.types.ElicitRequestParams
        callback_context: Any,  # langchain_mcp_adapters.callbacks.CallbackContext
    ) -> ElicitResult:
        """
        MCP elicitation callback. Fires when a tool calls ctx.elicit().

        ┌─ What happens here ──────────────────────────────────────────────┐
        │  1. Read session_id from contextvar (set by GraphRunner)         │
        │  2. Determine mode: FORM (JSON schema) or URL (external link)    │
        │  3. Register an asyncio.Future in ElicitationBridge              │
        │  4. Emit an SSE "elicitation" event to the UI                    │
        │  5. await the Future  ← BLOCKS HERE (MCP SSE stays alive)       │
        │  6. User POSTs /assist with is_elicitation_response=True         │
        │  7. bridge.resolve() sets the Future result                      │
        │  8. await unblocks → return ElicitResult to MCP server           │
        │  9. Tool resumes execution on MCP server side                    │
        └──────────────────────────────────────────────────────────────────┘

        Zero CPU is consumed during step 5→7. The coroutine is suspended
        in the asyncio event loop and other requests are served normally.
        """
        session_id = current_session_id.get()
        if not session_id:
            logger.error(
                "on_elicitation fired but current_session_id contextvar is empty. "
                "GraphRunner must set current_session_id before invoking the graph."
            )
            return ElicitResult(action="cancel", content={})

        # ── Determine elicitation mode ────────────────────────────────────────
        mode = ElicitationMode.FORM
        url: str | None = None
        raw = params.model_dump() if hasattr(params, "model_dump") else {}

        if raw.get("url"):
            mode = ElicitationMode.URL
            url = raw["url"]

        schema: dict | None = None
        if mode == ElicitationMode.FORM:
            requested = getattr(params, "requestedSchema", None)
            if requested:
                schema = (
                    requested.model_dump()
                    if hasattr(requested, "model_dump")
                    else requested
                )

        elicitation_id = str(uuid.uuid4())
        server_name = getattr(callback_context, "server_name", None) or self._server_name
        tool_name = getattr(callback_context, "tool_name", None) or ""

        logger.info(
            "Elicitation: session=%s id=%s mode=%s tool=%s message='%s'",
            session_id, elicitation_id, mode, tool_name, params.message,
        )

        elicitation_request = ElicitationRequest(
            elicitation_id=elicitation_id,
            mode=mode,
            message=params.message,
            schema=schema,
            url=url,
            server_name=server_name,
            tool_name=tool_name,
        )

        # ── Register Future ───────────────────────────────────────────────────
        future = self._bridge.register(
            session_id=session_id,
            elicitation_id=elicitation_id,
            server_name=server_name,
            tool_name=tool_name,
        )

        # ── Emit SSE event to UI ──────────────────────────────────────────────
        emitter = elicitation_event_emitter.get()
        if emitter:
            try:
                await emitter(elicitation_request)
            except Exception:
                logger.exception(
                    "Failed to emit elicitation SSE event: session=%s", session_id
                )
        else:
            logger.warning(
                "elicitation_event_emitter not set for session=%s. "
                "UI will not receive the elicitation prompt.",
                session_id,
            )

        # ── Block until user responds ─────────────────────────────────────────
        try:
            result: ElicitResult = await asyncio.wait_for(future, timeout=600)
            logger.info(
                "Elicitation resolved: session=%s id=%s action=%s",
                session_id, elicitation_id, result.action,
            )
            return result

        except asyncio.TimeoutError:
            logger.warning(
                "Elicitation timeout: session=%s id=%s", session_id, elicitation_id
            )
            return ElicitResult(action="cancel", content={})

        except (ElicitationTimeoutError, ElicitationCancelledError) as exc:
            logger.warning("Elicitation cancelled: %s", exc)
            return ElicitResult(action="cancel", content={})

        except Exception:
            logger.exception(
                "Unexpected error awaiting elicitation: session=%s", session_id
            )
            return ElicitResult(action="cancel", content={})

    # ── Private: cache cleanup ────────────────────────────────────────────────

    async def _cache_cleanup_loop(self) -> None:
        """Periodically evict expired tool cache entries to prevent memory growth."""
        while True:
            try:
                await asyncio.sleep(120)
                async with self._cache_lock:
                    expired_keys = [
                        k for k, v in self._tool_cache.items() if v.is_expired()
                    ]
                    for k in expired_keys:
                        del self._tool_cache[k]
                if expired_keys:
                    logger.debug(
                        "Tool cache cleanup: evicted %d expired entries", len(expired_keys)
                    )
            except asyncio.CancelledError:
                break
            except Exception:
                logger.exception("Unexpected error in tool cache cleanup")


def _hash_token(bearer_token: str) -> str:
    """
    SHA-256 hash of the bearer token, used as the cache key.
    Raw tokens are never stored in the cache dict or written to logs.
    """
    return hashlib.sha256(bearer_token.encode()).hexdigest()
