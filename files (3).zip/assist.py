"""
app/api/assist.py

The /assist endpoint — single entry point for all chat interactions.

Bearer token handling:
    Extracted from Authorization header, forwarded to MCPSessionManager
    which passes it to the MCP server for namespace enforcement.
    Never logged, never stored beyond the request lifetime.

Route A — Normal message (is_elicitation_response=False):
    Returns StreamingResponse (text/event-stream).
    SSE events flow until graph completion, including any elicitation
    prompts emitted mid-execution.

Route B — Elicitation response (is_elicitation_response=True):
    Resolves the pending asyncio.Future in ElicitationBridge.
    The original SSE stream (Route A) unblocks automatically.
    Returns lightweight JSON ACK — no streaming needed.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.core.elicitation_bridge import ElicitationBridge
from app.core.graph_runner import GraphRunner
from app.models.api import AssistRequest

logger = logging.getLogger(__name__)

router = APIRouter()
_bearer_scheme = HTTPBearer(auto_error=True)


# ── Dependency helpers ────────────────────────────────────────────────────────

def get_bridge(request: Request) -> ElicitationBridge:
    return request.app.state.elicitation_bridge


def get_graph_runner(request: Request) -> GraphRunner:
    return request.app.state.graph_runner


def get_bearer_token(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer_scheme),
) -> str:
    """
    Extract the raw Bearer token from the Authorization header.
    FastAPI's HTTPBearer handles the 401 if the header is absent or malformed.
    The token is passed to MCPSessionManager and never stored or logged here.
    """
    return credentials.credentials


# ── Endpoint ──────────────────────────────────────────────────────────────────

@router.post(
    "/assist",
    summary="Chat assist — single endpoint for all interactions",
    responses={
        200: {"description": "SSE stream (normal) or JSON ACK (elicitation response)"},
        400: {"description": "Missing elicitation_id on elicitation response"},
        401: {"description": "Missing or invalid Authorization header"},
        404: {"description": "No pending elicitation found for this session"},
        422: {"description": "Request body validation error"},
    },
)
async def assist(
    body: AssistRequest,
    bearer_token: str = Depends(get_bearer_token),
    bridge: ElicitationBridge = Depends(get_bridge),
    runner: GraphRunner = Depends(get_graph_runner),
) -> StreamingResponse | JSONResponse:
    """
    POST /assist

    All requests require:  Authorization: Bearer <token>
    The token is forwarded to the MCP server — it enforces which tools
    are accessible for this user's role (namespace).
    """
    if body.is_elicitation_response:
        return await _handle_elicitation_response(body, bridge)

    return _handle_normal_message(body, bearer_token, runner)


# ── Route handlers ────────────────────────────────────────────────────────────

async def _handle_elicitation_response(
    body: AssistRequest,
    bridge: ElicitationBridge,
) -> JSONResponse:
    """
    Resolve a pending elicitation Future.
    The original SSE stream unblocks immediately after this returns.
    No bearer token needed here — the session_id is the identity anchor.
    """
    if not body.elicitation_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "elicitation_id is required when is_elicitation_response=True. "
                "Use the elicitation_id value from the elicitation SSE event."
            ),
        )

    logger.info(
        "Elicitation response: session=%s id=%s action=%s",
        body.session_id, body.elicitation_id, body.elicitation_action,
    )

    resolved = bridge.resolve(
        session_id=body.session_id,
        elicitation_id=body.elicitation_id,
        action=body.elicitation_action,
        content=body.elicitation_content,
    )

    if not resolved:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"No pending elicitation for session='{body.session_id}' "
                f"elicitation_id='{body.elicitation_id}'. "
                "It may have already been resolved or timed out (10 min TTL)."
            ),
        )

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={
            "status": "ok",
            "session_id": body.session_id,
            "elicitation_id": body.elicitation_id,
            "action": body.elicitation_action,
            "message": "Elicitation resolved. Tool execution continuing on your stream.",
        },
    )


def _handle_normal_message(
    body: AssistRequest,
    bearer_token: str,
    runner: GraphRunner,
) -> StreamingResponse:
    """
    Start a new graph execution and return a streaming SSE response.
    The bearer token is passed to GraphRunner so tools are fetched and
    executed with the correct namespace for this user.
    """
    logger.info(
        "Assist request: session=%s message_len=%d",
        body.session_id, len(body.message),
    )

    return StreamingResponse(
        runner.run(
            session_id=body.session_id,
            user_input=body.message,
            bearer_token=bearer_token,
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",   # Prevent nginx from buffering SSE
            "Connection": "keep-alive",
        },
    )
