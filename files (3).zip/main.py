"""
app/main.py

FastAPI application entry point.

Startup order (lifespan):
1. ElicitationBridge  — starts TTL cleanup task
2. MCPSessionManager  — starts tool-cache cleanup task (no MCP connection yet —
                         connections are per-request)
3. PostgreSQL pool    — asyncpg pool, 5-20 connections
4. LangGraph          — compiled once with checkpointer (no tools needed here;
                         tools are injected per-request via config)
5. GraphRunner        — wires graph + bridge + mcp_manager

Shutdown reverses this: bridge → mcp_manager → postgres pool.
"""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

import asyncpg
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

from app.api.assist import router as assist_router
from app.core.elicitation_bridge import ElicitationBridge
from app.core.graph_runner import GraphRunner
from app.core.mcp_session_manager import MCPSessionManager
from app.graph.builder import build_graph

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("=== Startup ===")

    # 1. ElicitationBridge
    bridge = ElicitationBridge(
        ttl_seconds=int(os.getenv("ELICITATION_TTL_SECONDS", "600"))
    )
    await bridge.start()
    app.state.elicitation_bridge = bridge

    # 2. MCPSessionManager (no connection opened yet — per-request)
    mcp_manager = MCPSessionManager(
        server_url=os.environ["MCP_SERVER_URL"],
        bridge=bridge,
        server_name=os.getenv("MCP_SERVER_NAME", "default"),
        transport=os.getenv("MCP_TRANSPORT", "streamable_http"),
        tool_cache_ttl_seconds=int(os.getenv("TOOL_CACHE_TTL_SECONDS", "300")),
    )
    await mcp_manager.start()
    app.state.mcp_manager = mcp_manager

    # 3. PostgreSQL
    pool = await asyncpg.create_pool(
        os.environ["POSTGRES_DSN"],
        min_size=5,
        max_size=20,
        command_timeout=30,
    )
    checkpointer = AsyncPostgresSaver(pool)
    await checkpointer.setup()
    app.state.pg_pool = pool

    # 4. LangGraph — no mcp_tools at compile time (injected per-request via config)
    compiled_graph = build_graph(checkpointer=checkpointer)
    app.state.compiled_graph = compiled_graph

    # 5. GraphRunner
    app.state.graph_runner = GraphRunner(
        compiled_graph=compiled_graph,
        bridge=bridge,
        mcp_manager=mcp_manager,
    )

    logger.info("=== Ready ===")
    yield

    # Shutdown
    logger.info("=== Shutdown ===")
    await bridge.stop()
    await mcp_manager.stop()
    await pool.close()
    logger.info("=== Done ===")


def create_app() -> FastAPI:
    app = FastAPI(
        title="MCP Assist Service",
        version="1.0.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
        allow_credentials=True,
        allow_methods=["POST", "GET", "OPTIONS"],
        allow_headers=["*"],
    )

    app.include_router(assist_router, prefix="/api/v1", tags=["assist"])

    @app.get("/health", tags=["ops"])
    async def health():
        bridge: ElicitationBridge = app.state.elicitation_bridge
        return {
            "status": "ok",
            "pending_elicitations": bridge.pending_count(),
        }

    @app.post("/api/v1/tools/invalidate", tags=["ops"])
    async def invalidate_tools(request_obj: dict, request: FastAPI):
        """
        Force-refresh the tool cache for a bearer token.
        Useful when MCP server tool list changes for a user mid-session.
        Requires the same Authorization header as /assist.
        """
        # TODO: add admin auth guard before exposing this in production
        pass

    return app


app = create_app()
