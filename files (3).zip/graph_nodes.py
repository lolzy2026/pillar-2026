"""
app/nodes/graph_nodes.py

LangGraph node implementations for the assist graph.

Node execution order:
    guardrail_node → query_rephrase_node → mcp_node → answer_generation_node

The elicitation_node has been intentionally removed. Elicitation is handled
transparently inside mcp_node's tool.ainvoke() calls via the on_elicitation
callback wired in MCPSessionManager. No node-level elicitation logic needed.

Accessing per-request dependencies (mcp_client, mcp_tools) in nodes:
    LangGraph passes a RunnableConfig to every node. Per-request objects
    that must NOT be checkpointed (live connections, callable objects) are
    injected via config["configurable"] by GraphRunner, not via state.

    Pattern in a node:
        from langchain_core.runnables import RunnableConfig
        async def my_node(state: GraphState, config: RunnableConfig) -> dict:
            mcp_client = config["configurable"]["mcp_client"]
            tools = config["configurable"]["mcp_tools"]
"""

from __future__ import annotations

import logging

from langchain_core.messages import AIMessage
from langchain_core.runnables import RunnableConfig

from app.models.state import GraphState

logger = logging.getLogger(__name__)


# ── Guardrail Node ────────────────────────────────────────────────────────────

async def guardrail_node(state: GraphState, config: RunnableConfig) -> dict:
    """
    Safety guardrail node.

    Validates the user's input against safety and policy rules.
    Sets is_safe=False with a reason if the input should be blocked —
    the conditional edge will then route directly to answer_generation_node
    which produces a safe rejection response.

    TODO (teammates): Implement content moderation, PII detection, etc.
    """
    state.node_trace.append("guardrail_node")
    logger.debug("guardrail_node: session=%s", state.session_id)

    # STUB: always safe
    return {
        "is_safe": True,
        "guardrail_reason": "",
        "node_trace": state.node_trace,
    }


def should_continue_after_guardrail(state: GraphState) -> str:
    """Conditional edge: safe input continues, unsafe skips to answer."""
    return "query_rephrase_node" if state.is_safe else "answer_generation_node"


# ── Query Rephrase Node ───────────────────────────────────────────────────────

async def query_rephrase_node(state: GraphState, config: RunnableConfig) -> dict:
    """
    Query rephrasing node.

    Reformulates the user's raw input into a form better suited for
    tool selection and execution (e.g. resolving pronouns, adding context
    from conversation history, standardising terminology).

    TODO (teammates): Implement LLM-based rephrasing.
    """
    state.node_trace.append("query_rephrase_node")
    logger.debug("query_rephrase_node: session=%s", state.session_id)

    # STUB: pass through unchanged
    return {
        "rephrased_query": state.user_input,
        "node_trace": state.node_trace,
    }


# ── MCP Node ──────────────────────────────────────────────────────────────────

async def mcp_node(state: GraphState, config: RunnableConfig) -> dict:
    """
    MCP tool execution node.

    Retrieves the per-request MCP client and tool list from config
    (injected by GraphRunner — NOT from state, as these are live objects
    that must not be serialised into the PostgreSQL checkpoint).

    Tool execution flow:
        1. LLM selects which tools to call based on rephrased_query
        2. For each selected tool: await tool.ainvoke(args)
              └─ If tool calls ctx.elicit():
                    └─ on_elicitation callback fires TRANSPARENTLY
                    └─ Callback blocks on asyncio.Future (MCP session alive)
                    └─ SSE "elicitation" event emitted to UI
                    └─ User responds via POST /assist
                    └─ Future resolves → tool continues
        3. Collect all results into state.tool_results

    Elicitation is fully transparent here — this node needs zero special
    elicitation handling code. It just awaits tool.ainvoke() normally.

    Future parallel execution: when ready, fan out tool calls with
    asyncio.gather(). The elicitation bridge already supports concurrent
    elicitations keyed by (session_id, elicitation_id) tuples.

    TODO (teammates): Implement LLM-driven tool selection and result parsing.
    """
    state.node_trace.append("mcp_node")

    # Retrieve per-request injected dependencies from config
    configurable = config.get("configurable", {})
    mcp_client = configurable.get("mcp_client")
    tools: list = configurable.get("mcp_tools", [])

    if not mcp_client:
        logger.error("mcp_node: mcp_client not found in config. Was it injected by GraphRunner?")
        return {
            "tool_results": [],
            "error": "MCP client not available",
            "node_trace": state.node_trace,
        }

    logger.debug(
        "mcp_node: session=%s query='%s' available_tools=%s",
        state.session_id,
        state.rephrased_query,
        [t.name for t in tools],
    )

    # STUB: real implementation uses LLM to pick tools then calls them.
    # Example of how a real tool call looks (elicitation is transparent):
    #
    #   async with mcp_client as client:
    #       session_tools = await client.get_tools()
    #       # OR use the cached `tools` list passed via config
    #       result = await session_tools[0].ainvoke({"arg": "value"})
    #       # ^ if this tool calls ctx.elicit(), on_elicitation fires here.
    #       #   This line blocks until elicitation is resolved. Transparent.

    tool_results = [
        {
            "tool": "stub_tool",
            "result": f"Stub result for: {state.rephrased_query}",
        }
    ]

    return {
        "tool_results": tool_results,
        "messages": [AIMessage(content=f"Tools executed for: {state.rephrased_query}")],
        "node_trace": state.node_trace,
    }


# ── Answer Generation Node ────────────────────────────────────────────────────

async def answer_generation_node(state: GraphState, config: RunnableConfig) -> dict:
    """
    Final answer synthesis node.

    Combines tool results (and optionally conversation history) into a
    coherent natural-language response for the user.

    Also handles the guardrail rejection path: if is_safe=False, generates
    a safe refusal message instead of running tool-based answer generation.

    TODO (teammates): Implement LLM-based synthesis from tool_results.
    """
    state.node_trace.append("answer_generation_node")
    logger.debug("answer_generation_node: session=%s", state.session_id)

    if not state.is_safe:
        answer = (
            f"I'm not able to help with that request. {state.guardrail_reason}".strip()
        )
    else:
        results_text = "\n".join(
            f"- {r.get('tool', 'tool')}: {r.get('result', '')}"
            for r in state.tool_results
        )
        answer = f"Based on the available information:\n{results_text}"

    return {
        "final_answer": answer,
        "messages": [AIMessage(content=answer)],
        "node_trace": state.node_trace,
    }
